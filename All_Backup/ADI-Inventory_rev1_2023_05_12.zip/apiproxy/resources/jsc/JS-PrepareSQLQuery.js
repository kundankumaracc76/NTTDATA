const filterByCompanyId = 'company_id eq ';
const filterByItemId = ' and item_id eq ';
var companyCode=context.getVariable("companyCode");
var itemId=context.getVariable("id");
var customerNumber=context.getVariable("customerNumber");
var suffix=context.getVariable("suffix");

if(typeof companyCode ==='undefined' || companyCode ==="" || companyCode === null || companyCode === "null" || companyCode.length === 0){
 context.setVariable("errorMessage","Invalid/Missing CompanyCode : "+companyCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

if(typeof itemId === 'undefined' || itemId === null || itemId === "" || itemId === "null" || itemId.length === 0){
    context.setVariable("errorMessage","Invalid/Missing ItemId : "+itemId);
    context.setVariable("validation_failed","true");
    context.setVariable("is.error",true);
    throw null;
} 

if(typeof customerNumber ==='undefined' || customerNumber ==="" || customerNumber === null || customerNumber === "null" || customerNumber.length === 0){
 context.setVariable("errorMessage","Invalid/Missing customerNumber : "+customerNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

if(typeof suffix === 'undefined' || suffix === null || suffix === "" || suffix === "null" || suffix.length === 0){
    context.setVariable("errorMessage","Invalid/Missing suffix : "+suffix);
    context.setVariable("validation_failed","true");
    context.setVariable("is.error",true);
    throw null;
} 

var pathSuffix_asSQLQuery = filterByCompanyId+"'"+companyCode+"'"+filterByItemId+"'"+itemId+"'";
context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);


