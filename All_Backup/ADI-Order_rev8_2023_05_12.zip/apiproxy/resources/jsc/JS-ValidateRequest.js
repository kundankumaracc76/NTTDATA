var pathsuffix= context.getVariable("proxy.pathsuffix");

// Module to be executed when pathsuffix is /status/MobileApp
if (pathsuffix === "/status/MobileApp"){

var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null;
 }else if(req){

var invReq= JSON.parse(req);

// Extract Mandatory Variables
var Cust_Number = invReq.Cust_Number;
var Cust_Suffix = invReq.Cust_Suffix;

// Condition to check if mandatory values are not null and empty
if(typeof Cust_Number ==='undefined' || Cust_Number ==="" || Cust_Number === null){
 context.setVariable("errorMessage","Missing Cust_Number : "+Cust_Number);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }

else if(typeof Cust_Suffix ==='undefined' || Cust_Suffix ==="" || Cust_Suffix === null){
 context.setVariable("errorMessage","Missing Cust_Suffix : "+Cust_Suffix);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
        // Setting targetPathSuffix to be send to P21 host
        var pathSuffix_asSQLQuery = "Cust_Number eq "+Cust_Number+" and Cust_Suffix eq "+Cust_Suffix;
        context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
  }

}
