 var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null;
 }else if(req){

var request= JSON.parse(req);

// Extract Mandatory Variables
var CompanyName=request.Addresses[0].CompanyName;
var Address1=request.Addresses[0].Address1;
var City=request.Addresses[0].City;
var StateProv = request.Addresses[0].StateProv;
var PostalCode= request.Addresses[0].PostalCode;
var Country=request.Addresses[0].Country;

// Condition to check if mandatory values are not null and empty
if(typeof CompanyName ==='undefined' || CompanyName ==="" || CompanyName === null){
 context.setVariable("errorMessage","Missing CompanyName : "+CompanyName);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof Address1 ==='undefined' || Address1 ==="" || Address1 === null){
 context.setVariable("errorMessage","Missing Address1 : "+Address1);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof City ==='undefined' || City ==="" || City === null){
 context.setVariable("errorMessage","Missing City : "+City);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof StateProv ==='undefined' || StateProv ==="" || StateProv === null){
 context.setVariable("errorMessage","Missing StateProv : "+StateProv);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof PostalCode ==='undefined' || PostalCode ==="" || PostalCode === null){
 context.setVariable("errorMessage","Missing PostalCode : "+PostalCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof Country ==='undefined' || Country ==="" || Country === null){
 context.setVariable("errorMessage","Missing Country : "+Country);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

}