var resp = JSON.parse(context.getVariable("response.content"));

if(resp.value[0]){
    var success_resp = {
                "customer": resp.value[0],
                "returnCode":"00",
                "returnMessage":"Success"
        };
        
 context.setVariable("response.content",JSON.stringify(success_resp));
}

else{
   var error_resp = {
                "customer": null,
                "returnCode":"99",
                "returnMessage":"Error"
        };
    context.setVariable("response.content",JSON.stringify(error_resp)); 
}

