// Extract Mandatory Variables
var company_id = context.getVariable("company_id");
var customer_id = context.getVariable("customer_id");
var ship_to_id = context.getVariable("ship_to_id");


// Condition to check if mandatory values are not null and empty
if(typeof  company_id==='undefined' || company_id === "" || company_id === null || company_id === "null" || company_id.length === 0){
 context.setVariable("errorMessage","Invalid/Missing company_id : "+company_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof customer_id ==='undefined' || customer_id ==="" || customer_id === null || customer_id === "null" || customer_id.length === 0){
 context.setVariable("errorMessage","Invalid/Missing customer_id : "+customer_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

 else if(typeof ship_to_id ==='undefined' || ship_to_id ==="" || ship_to_id === null || ship_to_id === "null" || ship_to_id.length === 0){
 context.setVariable("errorMessage","Missing ship_to_id : "+ship_to_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}
 else if(company_id && customer_id && ship_to_id){
            const filterByCompanyId ="company_id eq ";
            const filterByCustomerId =  ' and customer_id eq ';
            const filterByShiptoId =  ' and ship_to_id eq ';
            var pathSuffix_asSQLQuery = filterByCompanyId+"'"+company_id+"'"+filterByCustomerId+customer_id+filterByShiptoId+ship_to_id;
            context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
      }


