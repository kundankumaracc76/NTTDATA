    var companyCode,invoiceNo; 
     var queryParamsList = request.queryParams;
    for(var queryParam in queryParamsList){
        switch(queryParam.toLowerCase()){
            case "compcode":
                companyCode = context.getVariable("request.queryparam." + queryParam);
                break;
            case "invoiceno":
                invoiceNo = context.getVariable("request.queryparam." + queryParam);
                break;
            }
    }

     if(typeof companyCode ==='undefined' || companyCode===null || companyCode==='' || companyCode.length === 0){
         context.setVariable("errorMessage","Invalid/Missing CompanyCode : "+companyCode);
         context.setVariable("validation_failed","true");
         context.setVariable("is.error",true); 
         throw null;
     }
      else if(typeof invoiceNo ==='undefined' || invoiceNo===null || invoiceNo==='' || invoiceNo.length === 0){
          context.setVariable("errorMessage","Invalid/Missing InvoiceNo : "+invoiceNo);
          context.setVariable("validation_failed","true");
          context.setVariable("is.error",true);
          throw null;
      }
      else if(companyCode && invoiceNo){
            const filterByCompanyId = 'company_id eq ';
            const filterByInvoiceNo = ' and invoice_no eq ';
            var pathSuffix_asSQLQuery = filterByCompanyId+"'"+companyCode+"'"+filterByInvoiceNo+"'"+invoiceNo+"'";
            context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
      }
      