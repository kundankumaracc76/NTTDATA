var req = JSON.parse(context.getVariable("request.content"));

var CompanyCode = req.CompanyCode;
var CustNumber = req.CustNumber;
var PDFDate = req.PDFDate;

var targetRequest = {
  "Name": "m_generatecustomerstatements",
  "Transactions": [
    {
      "DataElements": [
        {
          "Keys": [],
          "Name": "TABPAGE_1.tp_1_dw_1",
          "Type": "0",
          "Rows": [
            {
              "Edits": [
                {
                  "Name": "company_id",
                  "Value": CompanyCode		
                },
                {
                  "Name": "customer_id",
                  "Value": CustNumber
                },
                {
                  "Name": "beg_period",   
                  "Value": new Date(PDFDate + "T00:00:00Z").getMonth() + 1
                },
                {
                  "Name": "year",         
                  "Value": new Date(PDFDate + "T00:00:00Z").getFullYear()
                },
                {
                  "Name": "message",
                  "Value": "This is a Test Message"
                },                                
                {
                  "Name": "statement_type",
                  "Value": "Open Item/Balance Forward"
                },
                {
                  "Name": "sort_by",
                  "Value": "Statement Name"
                }
              ]
            }
          ]
        }
      ],
      "Status": 0
    }
  ],
  "UseCodeValues": false
};

// Set the target request as a context variable
context.setVariable("request.content", JSON.stringify(targetRequest));
context.setVariable("CompanyCode", CompanyCode);
context.setVariable("CustNumber", CustNumber);
context.setVariable("PDFDate", PDFDate);
