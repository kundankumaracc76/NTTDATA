var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true); 
     throw null; 
 }
 
else if(req){
var request= JSON.parse(context.getVariable("request.content"));
context.setVariable("userReq",request);

const filterByCompanyId = 'company_id eq ';
const filterByCustomerId = ' and customer_id eq ';

var compCode=request.CompanyCode;
var custNum=request.CustNumber;

if(typeof compCode ==='undefined' || compCode ==="" || compCode === null){
 context.setVariable("errorMessage","Invalid/Missing CompanyCode : "+compCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true); 
 throw null;
}

else if(typeof custNum ==='undefined' || custNum ==="" || custNum === null){
 context.setVariable("errorMessage","Invalid/Missing CustNumber : "+custNum);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true); 
 throw null;
}

}


var pathSuffix_asSQLQuery = filterByCompanyId+"'"+compCode+"'"+filterByCustomerId+custNum;
context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
//print("pathSuffix_asSQLQuery->",pathSuffix_asSQLQuery);
