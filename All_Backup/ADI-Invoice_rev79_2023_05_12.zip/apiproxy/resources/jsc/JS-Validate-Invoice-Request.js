var itemId=context.getVariable("reqInvoice.Id");
var InvType=context.getVariable("reqInvoice.InvType");

if(typeof itemId === 'undefined' || itemId === null || itemId === "" || itemId === "null" || itemId.length === 0){
    context.setVariable("errorMessage","Invalid/Missing ItemId : "+itemId);
    context.setVariable("validation_failed","true");
    context.setVariable("is.error",true);
    throw null;
}

if(typeof InvType === 'undefined' || InvType === null || InvType === "" || InvType === "null"){
    context.setVariable("errorMessage","Invalid/Missing InvType : "+InvType);
    context.setVariable("validation_failed","true");
    context.setVariable("is.error",true);
    throw null;
}

else if(itemId){
    const filterByItemId = "INVOICE_NBR eq ";
    var pathSuffix_asSQLQuery = filterByItemId+"'"+itemId+"'";
    context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
}


