 // CustInfo Response from service callout
var custinfo = JSON.parse(context.getVariable("Custinfo_Response.content"));

// InvoiceList Response
var invoicelist = JSON.parse(context.getVariable("response.content"));

// Response Variable
if (invoicelist.value[0]){
var temp = [];
invoicelist.value.forEach(function(obj) {
    var t ={
            "ORDER_NBR": obj.ORDER_NBR,
            "Aging": obj.Aging,
            "Balance": obj.Balance,
            "BalanceDue": obj.BalanceDue,
            "DueDate": obj.DueDate,
            "Number": obj.Number,
            "PO": obj.PO,
            "Reference": obj.Reference,
            "TransactionDate": obj.TransactionDate,
            "TrlrInd": obj.TrlrInd,
            "Type": obj.Type,
            "UPC": obj.UPC,
            "CustLocation": obj.CustLocation
    }
    temp.push(t)
});
}

var respcombine = {
    "ReturnCode": "00",
    "ReturnMsg": "Success",
    "RequestId": custinfo.value[0].RequestId,
    "ShowPayButton": custinfo.value[0].ShowPayButton,
    "CustomerInfo": {
        "CompanyName": custinfo.value[0].CompanyName,
        "Address1": custinfo.value[0].Address1,
        "Address2": custinfo.value[0].Address2,
        "Address3": custinfo.value[0].Address3,
        "Address4": custinfo.value[0].Address4,
        "CreditRep": custinfo.value[0].CreditRep,
        "PhoneNumber": custinfo.value[0].PhoneNumber,
        "FaxNumber": custinfo.value[0].FaxNumber,
        "Email": custinfo.value[0].Email,
        "AllowCCPayment": custinfo.value[0].AllowCCPayment,
        "AllowBankPayment": custinfo.value[0].AllowBankPayment,
        "CompCode": custinfo.value[0].CompCode,
        "CustNumber": custinfo.value[0].CustNumber,
        "Suffix": custinfo.value[0].Suffix,
        "ReturnCode": custinfo.value[0].ReturnCode,
        "ReturnMsg": custinfo.value[0].ReturnMsg,
        "RecordCnt": custinfo.value[0].RecordCnt,
        "RequestId": custinfo.value[0].RequestId,
        "Properties": custinfo.value[0].Properties
    },
    "CustomerInvoiceAgingInfo": JSON.parse(custinfo.value[0].CustomerInvoiceAgingInfo)[0],
    "InvoiceReasonCode": JSON.parse(custinfo.value[0].InvoiceReasonCode),
    "InvoiceListRow": temp,
    "PagingInfo": custinfo.value[0].PagingInfo
};

// Set response - APIGEE to Website
context.setVariable("response.content",JSON.stringify(respcombine));
