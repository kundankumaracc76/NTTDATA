// Extract Mandatory Variables
var custNumber = context.getVariable("request.queryparam.CustNumber");
var suffix = context.getVariable("request.queryparam.Suffix");

// Throw Error if Mandatory Variables are empty and invalid
if(typeof custNumber ==='undefined' || custNumber ==="" || custNumber === null){
        context.setVariable("errorMessage","Invalid/Missing custNumber : "+custNumber);
        context.setVariable("validation_failed","true");
        context.setVariable("is.error",true);
        throw null;
        }
        
if(typeof suffix ==='undefined' || suffix ==="" || suffix === null){
        context.setVariable("errorMessage","Invalid/Missing suffix : "+suffix);
        context.setVariable("validation_failed","true");
        context.setVariable("is.error",true);
        throw null;
        }
        
        //Set Pathsuffix
var pathSuffix_asSQLQuery ="CustNumber eq "+custNumber+" and Suffix eq "+suffix;
            context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
            
            //Remove QueryParam
            context.removeVariable("request.queryparam.CustNumber");
            context.removeVariable("request.queryparam.Suffix");
            
            context.setVariable("custNumber",custNumber);
            context.setVariable("suffix",suffix);