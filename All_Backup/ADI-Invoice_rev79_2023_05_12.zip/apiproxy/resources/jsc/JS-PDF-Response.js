var resp = JSON.parse(context.getVariable("response.content"));
var CompanyCode = context.getVariable("CompanyCode");
var CustNumber = context.getVariable("CustNumber");
var PDFDate = context.getVariable("PDFDate");

if (resp[0].ResponseStatus.StatusCode){
    
  var success_resp ={
  "CompanyCode": CompanyCode,
  "CustNumber": CustNumber,
  "ReturnCode": "00",
  "ReturnMessage": "Success",
  "PDFDate": PDFDate,
  "PDFData": resp[0].DocumentData
 };
 
context.setVariable("response.content", JSON.stringify(success_resp));  
}

else {
    var error_resp ={
  "CompanyCode": CompanyCode,
  "CustNumber": CustNumber,
  "ReturnCode": "99",
  "ReturnMessage": "Error",
  "PDFDate": PDFDate,
  "Message": resp.ErrorMessage
 };
context.setVariable("response.content", JSON.stringify(error_resp));  
}