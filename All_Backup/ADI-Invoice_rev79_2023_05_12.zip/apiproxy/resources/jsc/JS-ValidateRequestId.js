var itemsId=context.getVariable("reqConsolidatedInvoice.consolidatedinvoice");

if(typeof itemsId === 'undefined' || itemsId === null || itemsId === "" || itemsId === "null" || itemsId.length === 0){
    context.setVariable("errorMessage","Invalid/Missing ItemsId : "+itemsId);
    context.setVariable("validation_failed","true");
    context.setVariable("is.error",true);
}
else if(itemsId){
    const filterByItemsId = "INVOICE_NBR eq ";
    var pathSuffix_asSQLQuery = filterByItemsId+"'"+itemsId+"'";
    context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
}