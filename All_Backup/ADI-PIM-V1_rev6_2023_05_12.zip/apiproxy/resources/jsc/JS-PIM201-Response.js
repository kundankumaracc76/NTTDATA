var resp= JSON.parse(context.getVariable("response.content"));


if (resp.value[0]){
    var success_resp={
       "DOT COM IND": resp.value[0].dot_com_ind,
       "ReturnCode":"00",
       "ReturnMsg":"SUCCESSFUL"
    };
    context.setVariable("response.content",JSON.stringify(success_resp));
}

else{
    var error_resp={
       "DOT COM IND": "null",
       "ReturnCode":"99",
       "ReturnMsg":"ERROR"
    };
    context.setVariable("response.content",JSON.stringify(error_resp));
}