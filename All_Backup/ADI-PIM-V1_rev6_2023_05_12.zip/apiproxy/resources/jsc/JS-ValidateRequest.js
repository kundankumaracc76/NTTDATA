var req= context.getVariable("request.content");

 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){

// parse request json
var request= JSON.parse(req);

// condition to check if path suffix is /update
    var ItemNumber=request.ItemUpdateHeader.ItemNumber;
    var CompanyCode=request.ItemUpdateHeader["Company Code"];
    
    // -----------
var _orderBy = (typeof request.Sort ==='undefined' || request.Sort ==="" || request.Sort === null)? '' : request.Sort;	
var _top = (typeof request.PageSize ==='undefined' || request.PageSize ==="" || request.PageSize === null)? '' : pageSize;
var _skip = (typeof request.CurrentPage ==='undefined' || request.CurrentPage ==="" || request.CurrentPage === null)? '' :((request.CurrentPage-1) * _top );
// -----------
    
// check manadatory param if not null and valid
if(typeof ItemNumber ==='undefined' || ItemNumber ==="" || ItemNumber === null){
 context.setVariable("errorMessage","Invalid/Missing ItemNumber : "+ItemNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
if(typeof CompanyCode ==='undefined' || CompanyCode ==="" || CompanyCode === null){
 context.setVariable("errorMessage","Invalid/Missing CompanyCode : "+CompanyCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
    
     //Set Pathsuffix
            var pathSuffix_asSQLQuery ="item_id eq "+"'"+ItemNumber+"'"+" and company_id eq "+CompanyCode;
            
            // -----------
  if(_top !== '') pathSuffix_asSQLQuery +'&$orderby='+_top;
  if(_skip !== '') pathSuffix_asSQLQuery +'&$orderby='+_skip;
  if(_orderBy !== '') pathSuffix_asSQLQuery +'&$orderby='+_orderBy;
// -----------

            context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
}

