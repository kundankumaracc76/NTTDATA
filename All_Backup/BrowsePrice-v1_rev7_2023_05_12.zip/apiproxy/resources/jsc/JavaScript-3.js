var sgres =JSON.parse(context.getVariable('scattergather.response'));
//var sg=JSON.parse(sgres);
var res=[];
sgres.forEach( function(call){
   var body = call.hasOwnProperty('response') ? JSON.stringify(call.response) : null;
   var temp=JSON.parse(body);
    res.push(JSON.parse(temp));
});
    // print object
    	print(" - response_obj_1 --- ");	
	print(JSON.stringify(res));

var count=0

var resObj=[];
function map(obj){
    var k = obj[0].value.slice(2);
    temp={
            "ItemNum": k,
            "ItemQty": obj[3].value,
            "Visible": obj[6].value,
            "ItemPrice": obj[7].value,
            "CustPrice": obj[7].value,
            "SaleStartDate": obj[4].value,
            "SaleEndDate": obj[5].value,
            "LotCnt": null,
            "LotQty1": null,
            "LotPrice1": null,
            "LotQty2": null,
            "LotPrice2": null,
            "LotQty3": null,
            "LotPrice3": null,
            "Color": null,
            "Video": null,
            "MarkMsg": null,
            "RPMsg": null,
            "RecycleInd": null,
            "DGMsg": null,
            "DGItem": null,
            "CannotShipAir": null,
            "NewPriceCut": null,
            "WebOnlySale": null,
            "SalesIndicator": null,
            "LocalInventory": null, 
            "ItemWeight": null
    };
    //print(JSON.stringify(temp));
    resObj.push(temp);
    
}

var c=JSON.parse(context.getVariable("priceHeader"));



res.forEach(function(call){
    var con=call.hasOwnProperty('itemResults') ? JSON.stringify(call.itemResults) : null;
    if(con !== null){
        flag=JSON.parse(con);
        flag.forEach(function(mob){
            count=count+1
            var b = mob.hasOwnProperty('elements') ? JSON.stringify(mob.elements) : null;
            context.setVariable("q",b);
            var m=JSON.parse(context.getVariable("q"));
            map(m);
        });
    }
});

cnt=count.toString();
var ph={
    "BranchCode":"",
    "MoreWaysToSafe":c.MoreWaysToSafe,
    "CompCode":c.CompCode,
    "CustNumber":c.CustNumber,
    "Suffix":c.Suffix,
    "ReturnCode":"",
    "ReturnMsg":"",
    "ReturnCnt":cnt,
    "RequestId":c.RequestId,
    "Properties":{
        "Providers":"PROs"
    }
};

Response={
    "priceHeader": ph,
    "priceResponseDetailsList" : resObj
};



//var 

//print(JSON.stringify(s.elements));
response.content = '';
response.headers['Content-Type'] = 'application/json'; 
response.content = JSON.stringify(Response); 