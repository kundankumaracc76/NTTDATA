
// Functions -----------------------------

//Calculate Time Taken in Seconds
function timeTaken (startDate, endDate) {
    var oDiff = (endDate - startDate)/1000 + ' sec';
    return oDiff;
}

//Convert requestItems to prosItems
function requestItemsToProsItems(reqObjs){	
	print(" - requestItemsToProsItems --- ");	
	print(JSON.stringify(reqObjs));
	var prosItems = [];
	if(reqObjs !== null){
		for (var i in reqObjs.priceReqDetailList){
			var key=[];
			var overrides=[];
			var r1={
				"dimName":"PRODUCT",
				"nodeName":context.getVariable("CompCode")+"_"+reqObjs.priceReqDetailList[i].itemNum
				};
			key.push(r1);
			var r2={
				"dimName":"CUSTOMER",
				"nodeName":context.getVariable("customerName")
			};
			key.push(r2);
			var r3={
				"name":"ItemQty",
				"value":"1",
				"currency":"",
				"unit":"EA"
			};
			overrides.push(r3);
			var r4={
				"name":"RequestId",
				"value":"79c0f94b-b085-492b-a140-d03238f95cb1"
			};
			overrides.push(r4);
			var k={
				"key":key,
				"overrides":overrides
			};
			prosItems.push(k);
		}
	}
	return prosItems
}

// Convert prosItems to prosRequests
function prosItemsToProsRequests(prosItems){
	print(" - prosItemsToProsRequests --- ");
	print(JSON.stringify(prosItems));
	var requests = [];
	for (var j=0;j<prosItems.length;j+=9){
			var items=prosItems.slice(j,j+9);
			var batchItems={
				"batchItems":items
			};
			
		var r={
			"request" : {
			"url" :"https://evaluation-pps.us1.proscloud.com/api/method/name/RTPE_Umbrella_Method/values/batch",
			"operation" : context.getVariable('request.verb'),
			"headers" : hdrs,
			"batchItems":batchItems
			}
		};
			requests.push(r);
    }
	context.setVariable('scattergather.request',JSON.stringify(requests));
	return requests;
}

function sendProsRequests(prosRequests){
	print(" - sendProsRequests --- ");	
	print(JSON.stringify(prosRequests));
	try {
        var reqObj = prosRequests;
        var resObj = [];
        
        reqObj.forEach( function(call) {

            var url = call.request.url;
            var operation = call.request.operation;
            var headers = call.request.headers;
            var body = call.request.hasOwnProperty('batchItems') ? JSON.stringify(call.request.batchItems) : null;
            print('prosRequest body: '+ body);
            var request = new Request(url, operation, headers, body);
            var startTime = new Date().toISOString(); 
            
            //print("call-2");
            //print("url:", url);
            //print("operation:", operation);
            //print("headers:", JSON.stringify(headers));
            //print("body:", body);
            httpClient.send(request, function (res, err) {
                var r = {
                    "request" : call.request,
                    "startTime" : startTime
                };
                if (res) {
                    r.status = res.status;
                    r.response = res.content;
                } else {
                    r.status = {
                        "message" : err,
                        "code" : "504"
                    };
                }
                resObj.push(r);
                context.setVariable('scattergather.response', JSON.stringify(resObj));                
            });
        });
        context.setVariable('scattergather.response', JSON.stringify(resObj));
        print(" - sendProsResponses --- ");	
        print(JSON.stringify(resObj));
    } catch (e) {
        //print("exception in scatter-gather:: " +e.message);
        throw e;
    }
}

 // -- Format and Make Requests
var hdrs = {"Authorization" : "Bearer" + " " + context.getVariable("pros.apiAccessToken"),
			"Content-Type": "application/json"
		   }, 
	reqItems = context.getVariable("request.content") !== '' ? JSON.parse(context.getVariable("request.content")) : null,
	prosItems = requestItemsToProsItems(reqItems),
	prosRequests = prosItemsToProsRequests(prosItems);

request.content = '';
request.headers['Content-Type'] = 'application/json';
sendProsRequests(prosRequests);
