var reqObj = context.getVariable("request.content") !== '' ? JSON.parse(context.getVariable("request.content")) : null;

//Prepare headers for All Request - As All request accept same set of headers.
var hdrs = {
    "Authorization" : "Bearer" + " " + context.getVariable("pros.apiAccessToken"),
    "Content-Type": "application/json"
};
var batchItems=[];
var batch=[];
var batch_name=[];
var tempObj;
for (var i in reqObj.priceReqDetailList){
    var key=[];
    var overrides=[];
    var r1={
        "dimName":"PRODUCT",
        "nodeName":context.getVariable("CompCode")+"_"+reqObj.priceReqDetailList[i].itemNum
        };
    key.push(r1);
    var r2={
        "dimName":"CUSTOMER",
        "nodeName":context.getVariable("customerName")
    };
    key.push(r2);
    var r3={
        "name":"ItemQty",
        "value":"1",
        "currency":"",
        "unit":"EA"
    };
    overrides.push(r3);
    var r4={
        "name":"RequestId",
        "value":"79c0f94b-b085-492b-a140-d03238f95cb1"
    };
    overrides.push(r4);
    var k={
        "key":key,
        "overrides":overrides
    };
    batch.push(k);
}
temp1={};
for (var j=0;j<batch.length;j+=9){
        batchItems=batch.slice(j,j+9);
        temp1={
            "batchItems":batchItems
        };
        
    var r={
        "request" : {
        "url" :"https://evaluation-pps.us1.proscloud.com/api/method/name/RTPE_Umbrella_Method/values/batch",
    	"operation" : context.getVariable('request.verb'),
    	"headers" : hdrs,
    	"batchItems":temp1
        }
    };
        batch_name.push(r);
    }
request.content = '';
request.headers['Content-Type'] = 'application/json';
context.setVariable('scattergather.request',JSON.stringify(batch_name));
//print("scattergather.request --->" +JSON.stringify(batch_name));