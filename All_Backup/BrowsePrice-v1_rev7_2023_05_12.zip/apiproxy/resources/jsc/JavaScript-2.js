 //Function to Calculate Time Taken in Seconds
function timeTaken (startDate, endDate) {
    var oDiff = (endDate - startDate)/1000 + ' sec';
    return oDiff;
}

//SCATTER REQUEST(S) & GATHER RESPONSE(S)
if (context.getVariable('scattergather.request')) {
    try {
        var reqObj = JSON.parse(context.getVariable('scattergather.request'));
        var resObj = [];
          print("call-1");
        reqObj.forEach( function(call) {

            var url = call.request.url;
            var operation = call.request.operation;
            var headers = call.request.headers;
            var body = call.request.hasOwnProperty('batchItems') ? JSON.stringify(call.request.batchItems) : null;
            print('body: '+ body);
            var request = new Request(url, operation, headers, body);
            var startTime = new Date().toISOString(); 
            
            //print("call-2");
            //print("url:", url);
            //print("operation:", operation);
            //print("headers:", JSON.stringify(headers));
            //print("body:", body);
            httpClient.send(request, function (res, err) {
                
               /// print('----> TIMESTAMP : '+startTime);
                //print('----> URL : '+call.request.url);
                //print('-------------------------');
                
                var r = {
                    "request" : call.request,
                    "startTime" : startTime
                };
                if (res) {
                    r.status = res.status;
                    r.response = res.content;
                    //print("response :: "+ res.content);
                } else {
                    r.status = {
                        "message" : err,
                        "code" : "504"
                    };
                }
                //print("Res:",res);
                resObj.push(r);
                context.setVariable('scattergather.response', JSON.stringify(resObj));
                
            });
           // print("print end");
        });
        context.setVariable('scattergather.response', JSON.stringify(resObj));
    } catch (e) {
        //print("exception in scatter-gather:: " +e.message);
        throw e;
    }
}
print("scattergather.response --->" +JSON.stringify(resObj));