// Pros Response
var prosresp = JSON.parse(context.getVariable("scprosResponse.content"));
// Investory Response
var inventoryresp = JSON.parse(context.getVariable("response.content"));

var respcombine = {
    "PriceAndInventoryRespHeader": prosresp.priceResponseDetailsList[0],
    "PriceAndInventoryResDetailList": inventoryresp.value
};
context.setVariable("response.content",JSON.stringify(respcombine));

