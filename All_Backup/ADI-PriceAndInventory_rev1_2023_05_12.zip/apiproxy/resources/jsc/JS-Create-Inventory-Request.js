// Extract Pros response from service callout
// EV won't work as this is a global bug in APIGEE where EV policy treat elements with null value as not present
var req = JSON.parse(context.getVariable("request.content"));

// Extract Mandatory Parameter
//var company_id=req.PriceAndInventoryHeader.CompCode;
var company_id=412;
var customer_id=req.PriceAndInventoryHeader.CustNumber;
var ship_to_id=req.PriceAndInventoryHeader.Suffix;
var item_id=req.PriceAndInventoryHeader.ItemNum;


// Condition to check if mandatory values are not null and empty
if(typeof  company_id==='undefined' || company_id === "" || company_id === null || company_id === "null" || company_id.length === 0){
 context.setVariable("errorMessage","Invalid/Missing company_id : "+company_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

 else if(typeof customer_id ==='undefined' || customer_id ==="" || customer_id === null || customer_id === "null" || customer_id.length === 0){
 context.setVariable("errorMessage","Invalid/Missing customer_id : "+customer_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

 else if(typeof ship_to_id ==='undefined' || ship_to_id ==="" || ship_to_id === null || ship_to_id === "null" || ship_to_id.length === 0){
 context.setVariable("errorMessage","Missing ship_to_id : "+ship_to_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

 else if(typeof item_id ==='undefined' || item_id ==="" || item_id === null || item_id === "null" || item_id.length === 0){
 context.setVariable("errorMessage","Missing item_id : "+item_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

// Create P21 request for inventory
 else if(company_id && customer_id){
            const filterByCompanyId ="company_id eq ";
            const filterByCustomerId =  ' and customer_id eq ';
            const filterByShiptoId =  ' and ship_to_id eq ';
            const filterByitem_id =  ' and item_id eq ';
            var pathSuffix_asSQLQuery = filterByCompanyId+"'"+company_id+"'"+filterByitem_id+"'"+item_id+"'";
             context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
}
