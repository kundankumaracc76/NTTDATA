 var DeliveryLocRespHeader = JSON.parse(context.getVariable("resp.DeliveryLocRespHeader"));
var reqst= context.getVariable("request.content");
var re= JSON.parse(reqst);
var Request_Id=re.DLRH.RequestId;
DeliveryLocRespHeader[0].Returncode="00";
DeliveryLocRespHeader[0].ReturnMsg="Success";
DeliveryLocRespHeader[0].RequestId=Request_Id;

context.setVariable("responsedata",JSON.stringify(DeliveryLocRespHeader));

