   var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){

var request= JSON.parse(req);

const filterByCompanyId ="company_id eq ";
const filterByCustomerId =  ' and customer_id eq ';
const filterByShiptoId =  ' and ship_to_id eq ';

var company_id=request.DLRH.CompCode;
var customer_id=request.DLRH.CustNumber;
var ship_to_id=request.DLRH.Suffix;

// -----------
var _orderBy = (typeof request.Sort ==='undefined' || request.Sort ==="" || request.Sort === null)? '' : request.Sort;	
var _top = (typeof request.PageSize ==='undefined' || request.PageSize ==="" || request.PageSize === null)? '' : pageSize;
var _skip = (typeof request.CurrentPage ==='undefined' || request.CurrentPage ==="" || request.CurrentPage === null)? '' :((request.CurrentPage-1) * _top );
// -----------


if(typeof company_id ==='undefined' || company_id ==="" || company_id === null){
 context.setVariable("errorMessage","Invalid/Missing CompCode : "+company_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof customer_id ==='undefined' || customer_id ==="" || customer_id === null){
 context.setVariable("errorMessage","Invalid/Missing CustNumber : "+customer_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ship_to_id ==='undefined' || ship_to_id ==="" || ship_to_id === null){
 context.setVariable("errorMessage","Invalid/Missing Suffix : "+ship_to_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

}

var pathSuffix_asSQLQuery = filterByCompanyId+"'"+company_id+"'"+filterByCustomerId+customer_id+filterByShiptoId+ship_to_id;

// -----------
  if(_top !== '') pathSuffix_asSQLQuery +'&$top='+_top;
  if(_skip !== '') pathSuffix_asSQLQuery +'&$skip='+_skip;
  if(_orderBy !== '') pathSuffix_asSQLQuery +'&$orderby='+_orderBy;
// -----------
context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
print("pathSuffix_asSQLQuery->",pathSuffix_asSQLQuery)
