  var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){
var request= JSON.parse(context.getVariable("request.content"));
context.setVariable("userReq",request);
const filterByCompCode = 'CompCode eq ';
const filterByCustNumber = ' and CMM_CustNBR eq ';
const filterByOrderStartDate = ' and CMM_ORD_DATE ge ';
const filterByOrderEndDate = ' and CMM_ORD_DATE le ';

var compCode=request.Company_Code;
var custNum=request.Cust_Number;
var custSuffix=request.Cust_Suffix;
var orderStartDate=request.OrderStartDate;
var orderEndDate=request.OrderEndDate; 

// -----------
var _orderBy = (typeof request.Sort ==='undefined' || request.Sort ==="" || request.Sort === null)? '' : request.Sort;	
var _top = (typeof request.PageSize ==='undefined' || request.PageSize ==="" || request.PageSize === null)? '' : pageSize;
var _skip = (typeof request.CurrentPage ==='undefined' || request.CurrentPage ==="" || request.CurrentPage === null)? '' :((request.CurrentPage-1) * _top );
// -----------

if(typeof compCode ==='undefined' || compCode ==="" || compCode === null){
 context.setVariable("errorMessage","Invalid/Missing Company_Code : "+compCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}else if(typeof custNum ==='undefined' || custNum ==="" || custNum === null){
 context.setVariable("errorMessage","Invalid/Missing Cust_Number : "+custNum);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}else if(typeof custSuffix ==='undefined' || custSuffix ==="" || custSuffix === null){
 context.setVariable("errorMessage","Invalid/Missing Cust_Suffix : "+custSuffix);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}else if(typeof orderStartDate ==='undefined' || orderStartDate ==="" || orderStartDate === null){
 context.setVariable("errorMessage","Invalid/Missing OrderStartDate : "+orderStartDate);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}else if(typeof orderEndDate ==='undefined' || orderEndDate ==="" || orderEndDate === null){
 context.setVariable("errorMessage","Invalid/Missing OrderEndDate : "+orderEndDate);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}
}

var pathSuffix_asSQLQuery = filterByCompCode+"'"+compCode+"'"+filterByCustNumber+custNum+filterByOrderStartDate+orderStartDate+filterByOrderEndDate+orderEndDate;
// -----------
  if(_top !== '') pathSuffix_asSQLQuery +'&$orderby='+_top;
  if(_skip !== '') pathSuffix_asSQLQuery +'&$orderby='+_skip;
  if(_orderBy !== '') pathSuffix_asSQLQuery +'&$orderby='+_orderBy;
// -----------
context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
print("pathSuffix_asSQLQuery->",pathSuffix_asSQLQuery);
