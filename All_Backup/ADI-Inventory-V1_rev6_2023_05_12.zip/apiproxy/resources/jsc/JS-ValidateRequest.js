var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null;
     
 }
 else if(req){
const filterByCompanyId = "(company_id eq ";
const filterByLocationId = ' and location_id eq ';
const filterByItemId = ' and item_id eq ';
var invReq= JSON.parse(context.getVariable("request.content"));
context.setVariable("requestBody",invReq);
var queryData =[];
var compCode = invReq.priceHeader.COMPCODE;
var branchCode = invReq.priceHeader.BRANCHCODE;
var custNumber = invReq.priceHeader.CustNumber;
var suffix = invReq.priceHeader.Suffix;
var priceResponseDetailList=invReq.priceResponseDetailList;

if(typeof compCode ==='undefined' || compCode ==="" || compCode === null){
 context.setVariable("errorMessage","Invalid/Missing COMPCODE : "+compCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}else if(typeof branchCode ==='undefined' || branchCode ==="" || branchCode === null){
 context.setVariable("errorMessage","Invalid/Missing BRANCHCODE : "+branchCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}else if(typeof custNumber ==='undefined' || custNumber ==="" || custNumber === null){
 context.setVariable("errorMessage","Invalid/Missing CustNumber : "+custNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}else if(typeof suffix ==='undefined' || suffix ==="" || suffix === null){
 context.setVariable("errorMessage","Invalid/Missing Suffix : "+suffix);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}else if(typeof priceResponseDetailList ==='undefined' || priceResponseDetailList.length===0 || priceResponseDetailList === null){
 context.setVariable("errorMessage","Invalid/Missing priceResponseDetailList : "+priceResponseDetailList);
 context.setVariable("isError",true);
}
else if(typeof priceResponseDetailList[0].ItemNum ==='undefined' || priceResponseDetailList[0].ItemNum ==="" || priceResponseDetailList[0].ItemNum === null){
 context.setVariable("errorMessage","Invalid/Missing priceResponseDetailList[0].ItemNum : "+priceResponseDetailList[0].ItemNum);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}else if(priceResponseDetailList.length>0){
priceResponseDetailList.forEach(element =>{
  if(element.ItemNum.length>0 && queryData.length>0 )
  queryData.push(' or '+filterByCompanyId+"'"+compCode+"'"+filterByLocationId+branchCode+filterByItemId+"'"+element.ItemNum+"')");
  else queryData.push(filterByCompanyId+"'"+compCode+"'"+filterByLocationId+branchCode+filterByItemId+"'"+element.ItemNum+"')"); 
  
});
}
context.setVariable("targetPathSuffix",queryData.join(' '));
}
