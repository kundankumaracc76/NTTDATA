var resp= JSON.parse(context.getVariable('response.content'));
var request= context.getVariable("requestBody");
var priceResponseDetailList =[];
var priceHeader = {
         "COMPCODE": request.priceHeader.COMPCODE,
         "CustNumber": request.priceHeader.CustNumber,
         "Suffix": request.priceHeader.Suffix,
         "BRANCHCODE": request.priceHeader.BRANCHCODE,
         "RETURNCODE": "00",
         "RETURNMSG": "No record found",
         "RecordCnt": 0,
         "REQUESTID": request.priceHeader.REQUESTID
};

var branchIvnResponse = {
      "priceHeader" : priceHeader,
      "priceResponseDetailList" : priceResponseDetailList
  }; 

if(resp.value.length>0){
     for(var obj in resp.value){
        var data=resp.value[obj];
   var priceResponseDetail = {
             "ItemNum": data.item_id,
             "ItemQty": request.priceResponseDetailList.filter(element =>element.ItemNum ===data.item_id)[0].ItemQty,
             "MarkMsg": data.markmsg,
             "RPMSG": data.rpmsg,
             "RECYCLEIND": data.recycle_ind,
             "DGMSG": data.dgmsg,
             "DGITEM": data.dgitem,
             "CANNOTSHIPAIR": data.can_not_ship_air,
             "LOCALINVENTORY": data.inventory,
             "ITEMWEIGHT": data.weight
   };
   if(priceResponseDetail)priceResponseDetailList.push(priceResponseDetail);
}
priceHeader.RecordCnt = resp.value.length;
priceHeader.RETURNMSG="Success";
branchIvnResponse.priceHeader=priceHeader;
}
context.setVariable("response.content",JSON.stringify(branchIvnResponse));   
context.setVariable("response.header.X-TransactionId",context.getVariable('transactionID'));
