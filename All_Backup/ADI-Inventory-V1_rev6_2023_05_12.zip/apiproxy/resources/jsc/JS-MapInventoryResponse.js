 var tempInvResp= JSON.parse(context.getVariable("response.content"));
var inventoryResponse=null;
if(tempInvResp.value.length>0){
var invWareHouses =[];
var warehouseInventoryRespList=[];
var NatInv =0;
    for(var obj in tempInvResp.value){
        var value=tempInvResp.value[obj];
       var invWareHouse ={
           "Id": value.Id,
            "Name": value.Name,
            "Description": value.Description,
            "Address1": value.Address1,
            "Address2": value.Address2,
            "City": value.City,
            "State": value.State,
            "PostalCode": value.PostalCode,
            "ContactName": value.ContactName,
            "Phone": value.Phone,
            "ShipSite": value.ShipSite,
            "DeactivateOn": null,
            "IsDefault": false,
            "CountryId": value.CountryId,
            "CreatedOn": "",
            "CreatedBy": "",
            "ModifiedOn": "",
            "ModifiedBy": ""
           
       }
       var warehouseInventoryResp ={
            "Dc" : value.Dc,
            "Inventory" : value.Inventory?parseInt(value.Inventory):0,
            "Warehouse" :invWareHouse
        };
       warehouseInventoryRespList.push(warehouseInventoryResp);
       NatInv +=value.Inventory?parseInt(value.Inventory):0;
    }
    
  inventoryResponse = {
     "NatInv": NatInv,
     "ReturnCode" : "00",
     "ReturnMessage" :"Success",
     "WarehouseInventoryRespList" :warehouseInventoryRespList
 };  
}else if(tempInvResp.value.length===0) {
        inventoryResponse={
            "NatInv": 0,
            "ReturnCode": "00",
            "ReturnMessage": "Item number not found in item catalog.",
            "WarehouseInventoryRespList": []
            };
}

context.setVariable("response.content",JSON.stringify(inventoryResponse));
context.setVariable("response.header.X-TransactionId",context.getVariable('transactionID'));


        