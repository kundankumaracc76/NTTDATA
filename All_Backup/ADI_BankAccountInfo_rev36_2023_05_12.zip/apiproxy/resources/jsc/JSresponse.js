var responsedata = JSON.parse(context.getVariable("responsedata"));

responsedata.Returncode="00";
responsedata.ReturnMsg="Success";
responsedata.RequestId="389c56e5-6c97-43a0-9339-1a339276d6f9";

context.setVariable("response.content",JSON.stringify(responsedata));

