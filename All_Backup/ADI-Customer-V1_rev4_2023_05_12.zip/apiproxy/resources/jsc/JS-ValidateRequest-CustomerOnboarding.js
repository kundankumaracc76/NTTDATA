  var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){

var request= JSON.parse(req);

var CustomerNumber=request.CustomerOnBoardingUser.CUSTOMER_NUMBER;
var FirstName=request.CustomerOnBoardingUser.FIRST_NAME;
var LastName=request.CustomerOnBoardingUser.LAST_NAME;
var Email=request.CustomerOnBoardingUser.EMAIL;

if(typeof CustomerNumber ==='undefined' || CustomerNumber ==="" || CustomerNumber === null){
 context.setVariable("errorMessage","Invalid/Missing CUSTOMER_NUMBER : "+CustomerNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof FirstName ==='undefined' || FirstName ==="" || FirstName === null){
 context.setVariable("errorMessage","Invalid/Missing FIRST_NAME : "+FirstName);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof LastName ==='undefined' || LastName ==="" || LastName === null){
 context.setVariable("errorMessage","Invalid/Missing LAST_NAME : "+LastName);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
 
}else if(typeof Email ==='undefined' || Email ==="" || Email === null){
 context.setVariable("errorMessage","Invalid/Missing EMAIL : "+Email);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;

}

}