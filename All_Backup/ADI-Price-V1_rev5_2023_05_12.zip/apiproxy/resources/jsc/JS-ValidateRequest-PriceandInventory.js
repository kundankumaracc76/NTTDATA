 var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null;
 }else if(req){

var invReq= JSON.parse(req);

// Extract Mandatory Variables
var ItemNum = invReq.PriceAndInventoryHeader.ItemNum;
var PostalCode = invReq.PriceAndInventoryHeader.PostalCode;
var BranchCode = invReq.PriceAndInventoryHeader.BranchCode;
var CompCode = invReq.PriceAndInventoryHeader.CompCode;
var CustNumber = invReq.PriceAndInventoryHeader.CustNumber;
var Suffix = invReq.PriceAndInventoryHeader.Suffix;

// Array Declaration for mandatory fields
var CompCode_Check = ["412", "413", "414", "B"];

// Condition to check if mandatory values are not null and empty
if(typeof ItemNum ==='undefined' || ItemNum ==="" || ItemNum === null){
 context.setVariable("errorMessage","Missing ItemNum : "+ItemNum);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof PostalCode ==='undefined' || PostalCode ==="" || PostalCode === null){
 context.setVariable("errorMessage","Missing PostalCode : "+PostalCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof BranchCode ==='undefined' || BranchCode ==="" || BranchCode === null){
 context.setVariable("errorMessage","Missing BranchCode : "+BranchCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof CompCode ==='undefined' || CompCode ==="" || CompCode === null){
 context.setVariable("errorMessage","Missing CompCode : "+CompCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof CustNumber ==='undefined' || CustNumber ==="" || CustNumber === null){
 context.setVariable("errorMessage","Missing CustNumber : "+CustNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof Suffix ==='undefined' || Suffix ==="" || Suffix === null){
 context.setVariable("errorMessage","Missing Suffix : "+Suffix);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

// Mandatory Params value check code
else if(!(isInArray(CompCode, CompCode_Check))){
 context.setVariable("errorMessage","Invalid CompCode  : "+CompCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

}

// Function to check values of mandatory parameters
function isInArray(value, array) {
  return array.indexOf(value) > -1;
}


