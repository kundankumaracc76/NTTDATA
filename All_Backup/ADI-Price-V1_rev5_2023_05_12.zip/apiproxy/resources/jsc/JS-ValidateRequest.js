var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null;
 }else if(req){

var invReq= JSON.parse(req);

// Extract Mandatory Variables
var CompCode = invReq.priceHeader.CompCode;
var CustNumber = invReq.priceHeader.CustNumber;
var itemNum = invReq.priceReqDetailList[0].itemNum;
var quantity = invReq.priceReqDetailList[0].quantity;
var unitOfMeasure = invReq.priceReqDetailList[0].unitOfMeasure;

// Condition to check if mandatory values are not null and empty
if(typeof CompCode ==='undefined' || CompCode ==="" || CompCode === null){
 context.setVariable("errorMessage","Missing CompCode : "+CompCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof CustNumber ==='undefined' || CustNumber ==="" || CustNumber === null){
 context.setVariable("errorMessage","Missing CustNumber : "+CustNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof itemNum ==='undefined' || itemNum ==="" || itemNum === null){
 context.setVariable("errorMessage","Missing itemNum : "+itemNum);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof quantity ==='undefined' || quantity ==="" || quantity === null){
 context.setVariable("errorMessage","Missing quantity : "+quantity);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof unitOfMeasure ==='undefined' || unitOfMeasure ==="" || unitOfMeasure === null){
 context.setVariable("errorMessage","Missing unitOfMeasure : "+unitOfMeasure);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

}



