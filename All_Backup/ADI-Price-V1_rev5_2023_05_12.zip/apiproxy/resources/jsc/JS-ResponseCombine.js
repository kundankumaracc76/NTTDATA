 var sgres =JSON.parse(context.getVariable('scattergather.response'));
var res=[];
sgres.forEach( function(call){
   var body = call.hasOwnProperty('response') ? JSON.stringify(call.response) : null;
   var temp=JSON.parse(body);
    res.push(JSON.parse(temp));
});


var count=0;

var resObj=[];
function map(obj){

// loop on map obj array
var ItemNum ="";
var ItemQty ="";
var Visible ="";
var ItemPrice ="";
var CustPrice ="";
var SaleStartDate ="";
var SaleEndDate ="";
var MarkMsg ="";
var RPMsg ="";
var RecycleInd ="";
var DGMsg ="";
var DGItem ="";
var CannotShipAir ="";
var NewPriceCut ="";
var WebOnlySale ="";
var SalesIndicator ="";
var ItemWeight ="";
var PriceCode ="";

// loop on map obj array
for (var i = 0; i < obj.length; i++) {

switch(obj[i].name) {
  case "IN_PRODUCT":
    ItemNum = obj[i].value;
    break;
  case "IN_QUANTITY":
    ItemQty = obj[i].value;
    break;
  case "OUT_VISIBILITY_FLAG":
    Visible = obj[i].value;
    break;
  case "OUT_CUSTOMER_STD_PRICE":
    ItemPrice = obj[i].value;
    break;
  case "OUT_CUSTOMER_FINAL_PRICE":
    CustPrice = obj[i].value;
    break;
  case "OUT_CUSTOMER_PRICE_CODE":
    PriceCode = obj[i].value;
    break;
  case "OUT_SALES_START_DATE":
    SaleStartDate = obj[i].value;
    break;
  case "OUT_SALES_END_DATE":
    SaleEndDate = obj[i].value;
    break;
  case "OUT_PROD_MESSAGES":
    MarkMsg = obj[i].value;
    break;
  case "rpmsg":
    RPMsg = obj[i].value;
    break;
  case "OUT_PROD_RECYCLE":
    RecycleInd = obj[i].value;
    break;
  case "OUT_PROD_DANGER_MSG":
    DGMsg = obj[i].value;
    break;
  case "OUT_PROD_DANGER":
    DGItem = obj[i].value;
    break;
  case "OUT_PROD_SHIP":
    CannotShipAir = obj[i].value;
    break;
  case "newpricecut":
    NewPriceCut = obj[i].value;
    break;
  case "OUT_WEB_ONLY":
    WebOnlySale = obj[i].value;
    break;
  case "OUT_SALES_INDICATOR":
    SalesIndicator = obj[i].value;
    break;
  case "OUT_PROD_WEIGHT":
    ItemWeight = obj[i].value;
    break;
			}

}

    temp={
            "ItemNum": ItemNum,
            "ItemQty": ItemQty,
            "Visible": Visible,
            "ItemPrice": ItemPrice,
            "CustPrice": CustPrice,
            "SaleStartDate": SaleStartDate,
            "SaleEndDate": SaleEndDate,
            "MarkMsg": MarkMsg,
            "RPMsg": RPMsg,
            "RecycleInd": RecycleInd,
            "DGMsg": DGMsg,
            "DGItem": DGItem,
            "CannotShipAir": CannotShipAir,
            "NewPriceCut": NewPriceCut,
            "WebOnlySale": WebOnlySale,
            "SalesIndicator": SalesIndicator,
            "ItemWeight": ItemWeight,
            "PriceCode": PriceCode
    };
	
    resObj.push(temp);
    
}

var c=JSON.parse(context.getVariable("priceHeader"));


res.forEach(function(call){
    var con=call.hasOwnProperty('itemResults') ? JSON.stringify(call.itemResults) : null;
    if(con !== null){
        flag=JSON.parse(con);
        flag.forEach(function(mob){
            count=count+1;
            var b = mob.hasOwnProperty('elements') ? JSON.stringify(mob.elements) : null;
            if (b === null){
                context.setVariable("errorMessage",JSON.stringify(flag));
                context.setVariable("is.error",true);
                throw null;
            }
            context.setVariable("q",b);
            var m=JSON.parse(context.getVariable("q"));
            map(m);
        });
    }
});

cnt=count.toString();
cntReq = context.getVariable('reqitems').toString();

var ph={
    "BranchCode":"",
    "MoreWaysToSafe":c.MoreWaysToSafe,
    "CompCode":c.CompCode,
    "CustNumber":c.CustNumber,
    "Suffix":c.Suffix,
    "ReturnCode":cntReq == cnt ? "00" : "99" ,
    "ReturnMsg":cntReq == cnt ? "Success" : "Error",
    "RecordCnt":cnt,
    "RequestId":c.RequestId,
    "Properties":{
        "Providers":"PROs"
    }
};

Response={
    "priceHeader": ph,
    "priceResponseDetailsList" : resObj
};

response.content = '';
response.headers['Content-Type'] = 'application/json'; 
response.content = JSON.stringify(Response); 