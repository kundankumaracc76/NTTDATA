  var resp = JSON.parse(context.getVariable('response.content'));
 var userReq=context.getVariable("userReq");
var orderListResp=null;
var OrderListResponseList=[];
 if(resp.value.length>0){
    for(var obj in resp.value){
         var data= resp.value[obj];
         var orderlist ={
             "CMM_CustNBR" : data.CMM_CustNBR ,
             "CMM_SUFF" : data.CMM_SUFF,
             "CMM_ORD_NBR" : data.CMM_ORD_NBR,
             "CMM_TYPE" : data.CMM_TYPE,
             "CMM_PO_NBR" : data.CMM_PO_NBR,
             "CMM_REF_NBR" : data.CMM_REF_NBR,
            "CMM_ORD_STATUS" : data.CMM_ORD_STATUS,
            "CMM_ORD_STATUS_DESC" : data.CMM_ORD_STATUS_DESC,
            "CMM_CREATION_DATE" : data.CMM_CREATION_DATE,
            "CMM_ORD_DATE" : data.CMM_ORD_DATE,
            "CMM_NBR_ITEMS" : data.CMM_NBR_ITEMS,
            "CMM_MATERIAL_COST_S" : data.CMM_MATERIAL_COST_S,
            "CMM_MATERIAL_COST" : data.CMM_MATERIAL_COST,
            "CMM_REQUESTOR_NAME" : data.CMM_REQUESTOR_NAME,
            "CMM_PROJ_NAME" : data.CMM_PROJ_NAME,
            "CMM_ORD_SUB_STATUS_DESC" : data.CMM_ORD_SUB_STATUS_DESC,
            "CMM_ITEMS" : data.CMM_ITEMS?data.CMM_ITEMS.split(','):null
         };
        OrderListResponseList.push(orderlist) 
     }
orderListResp = {
    "OrderListResponseList" : OrderListResponseList,
    "CurrentPage" :0,
    "TotalCount" :0,
    "PageSize" :0,
    "hasProjectQuote" : true,
    "hasRegularQuote" : true,
    "CompCode": userReq.Company_Code,
	"CustNumber": userReq.Cust_Number,
	"Suffix": userReq.Cust_Suffix,
	 "ReturnCode": "00",
	 "ReturnMsg": "Success",
	 "RecordCnt": resp.value.length,
	 "RequestId": '',
	 "Properties": {}
};
     
 }
 else if(resp.value.length === 0){
     orderListResp = {
    "OrderListResponseList" : OrderListResponseList,
    "CurrentPage" :0,
    "TotalCount" :0,
    "PageSize" :0,
    "hasProjectQuote" : true,
    "hasRegularQuote" : true,
    "CompCode": userReq.Company_Code,
	"CustNumber": userReq.Cust_Number,
	"Suffix": userReq.Cust_Suffix,
	"ReturnCode": "00",
	"ReturnMsg": "No Record Found.",
	 "RecordCnt": 0,
	 "RequestId": "",
	 "Properties": {}
};
 }
 
context.setVariable("response.content",JSON.stringify(orderListResp));
context.setVariable("response.header.X-TransactionId",context.getVariable('transactionID'));