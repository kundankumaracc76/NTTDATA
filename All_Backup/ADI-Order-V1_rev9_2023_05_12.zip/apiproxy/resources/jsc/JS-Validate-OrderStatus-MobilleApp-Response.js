 var resp = JSON.parse(context.getVariable("response.content"));

// Check if reqponse array have < 4 items or more than 4 Items
if (resp.value[0].LineItems.split(",").length > 3){
    var LineItems = resp.value[0].LineItems.split(",").slice(0,4);
}
else{
    var LineItems = resp.value[0].LineItems.split(",");
    var items_to_push = 4-(LineItems.length);
    for (var i = 0; i < items_to_push; i++) {
            LineItems.push("");
          }
}

// Modify Response of other API Calls
    if (resp.value[0]){
        var success_response = {
            "Cust_Number": resp.value[0].Cust_Number.toString(),
            "Cust_Suffix":  resp.value[0].Cust_Suffix.toString(),
            "Order_Dt":  resp.value[0].Order_Dt,
            "Order_Nbr":  resp.value[0].Order_Nbr,
            "PO_Nbr":  resp.value[0].PO_Nbr,
            "Order_Total":  resp.value[0].Order_Total,
            "Tot_Line_Item_SU":  resp.value[0].Tot_Line_Item_SU,
            "Branch_Name_SU":  resp.value[0].Branch_Name_SU,
            "Order_Status_Desc":  resp.value[0].Order_Status_Desc,
            "ReturnCode": "00",
            "ReturnMsg": "Success",
            "LineItems": LineItems
            };

    context.setVariable("response.content", JSON.stringify(success_response));
    }
    // Error Condition
    else {
        var error_response = {
        "ErrorText": resp.value,
        "ResponseCode": "99",
        "ResponseMsg": "Failed"
        };
        
    context.setVariable("response.content", JSON.stringify(error_response));
    } 
    