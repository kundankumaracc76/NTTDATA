var CustNumber = context.getVariable("ordersubmit.CustNumber");
var Suffix = context.getVariable("ordersubmit.Suffix");
var CompCode = context.getVariable("ordersubmit.CompCode");
var OrderNumber = context.getVariable("ordersubmit.OrderNumber");
var OrderType = context.getVariable("ordersubmit.OrderType");

if (OrderType === "JobContract"){
    var targetreq = {
    "OrderImport": {
        "Request": {
            "B2BSellerVersion": {
                "MajorVersion": "5",
                "MinorVersion": "11",
                "BuildNumber": "100"
            },
            "CustomerCode": "10009",
            "StoreName": "412",
            "WebReferenceNumber": "{{$guid}}",
            "Anonymous": "N",
            "PONumber": "",
            "NotepadText": "",
            "NotepadDisplayArea": "",
            "UseContractAddress": "False",
            "FreightCode": "",
            "FreightAmount": "",
            "ContactID": "",
            "RequireDate": "{{todayDate}}",
            "ContractUID": OrderNumber,						
            "ImportAsQuote": "False",
            "QuoteNumber": "",
            "WillCall": "",
            "PackingBasis": "",
            "BlindShip": "",
            "UseSystemSettingForPricingUnit": "TRUE",
            "CustomerShipTo": {
                "ShipToID": "100905",
                "ShipToAddress": {
                    "ShipToCompanyName": "",
                    "ShipToAddress1": "",
                    "ShipToAddress2": "",
                    "ShipToAddress3": "",
                    "ShipToCity": "",
                    "ShipToState": "",
                    "ShipToZip": "",
                    "ShipToCountry": ""
                },
                "ShipToContactFirstName": "",
                "ShipToContactLastName": "",
                "ShipToContactSalutation": "",
                "ShipToContactTitle": "",
                "ShipToPhone": "",
                "ShipToFax": "",
                "ShipToEMail": "",
                "ShipToCarrierId": "101193"
            },
            "CreditCard": {
                "CV2Number": "***",
                "CardType": "",
                "AuthorizationCode": "",
                "CardNumber": "****************",
                "ExpirationMonth": "**",
                "ExpirationYear": "**",
                "ChargeAmount": "",
                "CardHolder": {
                    "FirstName": "",
                    "LastName": "",
                    "Address": {
                        "CompanyName": "",
                        "Address1": "",
                        "Address2": "",
                        "City": "",
                        "State": "",
                        "Zip": "",
                        "Country": ""
                    }
                },
                "ElementPaymentAccountID": "",
                "ElementTransactionID": "",
                "ElementProcessorID": "",
                "AVSResponseCode": "",
                "CVVResponseCode": ""
            },
            "ListOfMerchandiseCredits": {
                "MerchandiseCredit": {
                    "MerchandiseCreditNumber": "",
                    "Amount": ""
                }
            },
            "ListOfLineItems": {
                "LineItem": {
                    "ItemID": "1000049",
                    "OrderedAs": "",
                    "OrderQuantity": "1",
                    "CustomerPartNumber": "",
                    "UnitName": "PK",
                    "UnitSize": "1.0000",
                    "UnitPrice": "",
                    "SourceLocation": "100001",
                    "RequireDate": "2009-01-07",
                    "ContractUID": OrderNumber,					
                    "NotepadText": "",
                    "NotepadDisplayArea": "",
                    "QuoteLineNumber": "",
                    "QuoteLineComplete": "",
                    "NewWebItem": "",
                    "BinID": "",
                    "Description": "",
                    "ExtendedDescription": "",
                    "SupplierID": "",
                    "CalculateTax": "",
                    "MinimumSurchargeItem": "",
                    "CarrierID": "",
                    "IncomingFreight": ""
                }
            },
            "WebShopperId": "",
            "WebShopperEmailAddress": "",
            "ListOfCoupons": {
                "Coupon": {
                    "CouponNumber": ""
                }
            }
        }
    }
};

context.setVariable("request.content",JSON.stringify(targetreq));
}

else if (OrderType === "Quote"){
    var targetreq = {
    "OrderImport": {
        "Request": {
            "B2BSellerVersion": {
                "MajorVersion": "5",
                "MinorVersion": "11",
                "BuildNumber": "100"
            },
            "CustomerCode": "10009",
            "StoreName": "412",
            "WebReferenceNumber": "{{$guid}}",
            "Anonymous": "N",
            "PONumber": "",
            "NotepadText": "",
            "NotepadDisplayArea": "",
            "UseContractAddress": "False",
            "FreightCode": "",
            "FreightAmount": "",
            "ContactID": "",
            "RequireDate": "{{todayDate}}",
            "ContractUID": "",
            "ImportAsQuote": "False",
            "QuoteNumber": OrderNumber,
            "WillCall": "",
            "PackingBasis": "",
            "BlindShip": "",
            "UseSystemSettingForPricingUnit": "TRUE",
            "CustomerShipTo": {
                "ShipToID": "100905",
                "ShipToAddress": {
                    "ShipToCompanyName": "",
                    "ShipToAddress1": "",
                    "ShipToAddress2": "",
                    "ShipToAddress3": "",
                    "ShipToCity": "",
                    "ShipToState": "",
                    "ShipToZip": "",
                    "ShipToCountry": ""
                },
                "ShipToContactFirstName": "",
                "ShipToContactLastName": "",
                "ShipToContactSalutation": "",
                "ShipToContactTitle": "",
                "ShipToPhone": "",
                "ShipToFax": "",
                "ShipToEMail": "",
                "ShipToCarrierId": "101193"
            },
            "CreditCard": {
                "CV2Number": "***",
                "CardType": "",
                "AuthorizationCode": "",
                "CardNumber": "****************",
                "ExpirationMonth": "**",
                "ExpirationYear": "**",
                "ChargeAmount": "",
                "CardHolder": {
                    "FirstName": "",
                    "LastName": "",
                    "Address": {
                        "CompanyName": "",
                        "Address1": "",
                        "Address2": "",
                        "City": "",
                        "State": "",
                        "Zip": "",
                        "Country": ""
                    }
                },
                "ElementPaymentAccountID": "",
                "ElementTransactionID": "",
                "ElementProcessorID": "",
                "AVSResponseCode": "",
                "CVVResponseCode": ""
            },
            "ListOfMerchandiseCredits": {
                "MerchandiseCredit": {
                    "MerchandiseCreditNumber": "",
                    "Amount": ""
                }
            },
            "ListOfLineItems": {
                "LineItem": {
                    "ItemID": "1000049",
                    "OrderedAs": "",
                    "OrderQuantity": "1",
                    "CustomerPartNumber": "",
                    "UnitName": "PK",
                    "UnitSize": "1.0000",
                    "UnitPrice": "",
                    "SourceLocation": "100001",
                    "RequireDate": "2009-01-07",
                    "ContractUID": "",
                    "NotepadText": "",
                    "NotepadDisplayArea": "",
                    "QuoteLineNumber": "",	
                    "QuoteLineComplete": "",
                    "NewWebItem": "",
                    "BinID": "",
                    "Description": "",
                    "ExtendedDescription": "",
                    "SupplierID": "",
                    "CalculateTax": "",
                    "MinimumSurchargeItem": "",
                    "CarrierID": "",
                    "IncomingFreight": ""
                }
            },
            "WebShopperId": "",
            "WebShopperEmailAddress": "",
            "ListOfCoupons": {
                "Coupon": {
                    "CouponNumber": ""
                }
            }
        }
    }
};

context.setVariable("request.content",JSON.stringify(targetreq));
}

else{
    var targetreq = {
    "OrderImport": {
        "Request": {
            "B2BSellerVersion": {
                "MajorVersion": "5",
                "MinorVersion": "11",
                "BuildNumber": "100"
            },
            "CustomerCode": "10009",
            "StoreName": "412",
            "WebReferenceNumber": "{{$guid}}",
            "Anonymous": "N",
            "PONumber": "",
            "NotepadText": "",
            "NotepadDisplayArea": "",
            "UseContractAddress": "False",
            "FreightCode": "",
            "FreightAmount": "",
            "ContactID": "",
            "RequireDate": "{{todayDate}}",
            "ContractUID": "",
            "ImportAsQuote": "False",
            "QuoteNumber": "",
            "WillCall": "",
            "PackingBasis": "",
            "BlindShip": "",
            "UseSystemSettingForPricingUnit": "TRUE",
            "CustomerShipTo": {
                "ShipToID": "100905",
                "ShipToAddress": {
                    "ShipToCompanyName": "",
                    "ShipToAddress1": "",
                    "ShipToAddress2": "",
                    "ShipToAddress3": "",
                    "ShipToCity": "",
                    "ShipToState": "",
                    "ShipToZip": "",
                    "ShipToCountry": ""
                },
                "ShipToContactFirstName": "",
                "ShipToContactLastName": "",
                "ShipToContactSalutation": "",
                "ShipToContactTitle": "",
                "ShipToPhone": "",
                "ShipToFax": "",
                "ShipToEMail": "",
                "ShipToCarrierId": "101193"
            },
            "CreditCard": {
                "CV2Number": "***",
                "CardType": "",
                "AuthorizationCode": "",
                "CardNumber": "****************",
                "ExpirationMonth": "**",
                "ExpirationYear": "**",
                "ChargeAmount": "",
                "CardHolder": {
                    "FirstName": "",
                    "LastName": "",
                    "Address": {
                        "CompanyName": "",
                        "Address1": "",
                        "Address2": "",
                        "City": "",
                        "State": "",
                        "Zip": "",
                        "Country": ""
                    }
                },
                "ElementPaymentAccountID": "",
                "ElementTransactionID": "",
                "ElementProcessorID": "",
                "AVSResponseCode": "",
                "CVVResponseCode": ""
            },
            "ListOfMerchandiseCredits": {
                "MerchandiseCredit": {
                    "MerchandiseCreditNumber": "",
                    "Amount": ""
                }
            },
            "ListOfLineItems": {
                "LineItem": {
                    "ItemID": "1000049",
                    "OrderedAs": "",
                    "OrderQuantity": "1",
                    "CustomerPartNumber": "",
                    "UnitName": "PK",
                    "UnitSize": "1.0000",
                    "UnitPrice": "",
                    "SourceLocation": "100001",
                    "RequireDate": "2009-01-07",
                    "ContractUID": "",
                    "NotepadText": "",
                    "NotepadDisplayArea": "",
                    "QuoteLineNumber": "",
                    "QuoteLineComplete": "",
                    "NewWebItem": "",
                    "BinID": "",
                    "Description": "",
                    "ExtendedDescription": "",
                    "SupplierID": "",
                    "CalculateTax": "",
                    "MinimumSurchargeItem": "",
                    "CarrierID": "",
                    "IncomingFreight": ""
                }
            },
            "WebShopperId": "",
            "WebShopperEmailAddress": "",
            "ListOfCoupons": {
                "Coupon": {
                    "CouponNumber": ""
                }
            }
        }
    }
};

context.setVariable("request.content",JSON.stringify(targetreq));
}