var req=JSON.parse(context.getVariable("request.content"));

var custNumber=req.CustNumber;
var suffix=req.Suffix;

// -----------
var _orderBy = (typeof request.Sort ==='undefined' || request.Sort ==="" || request.Sort === null)? '' : request.Sort;	
var _top = (typeof request.PageSize ==='undefined' || request.PageSize ==="" || request.PageSize === null)? '' : pageSize;
var _skip = (typeof request.CurrentPage ==='undefined' || request.CurrentPage ==="" || request.CurrentPage === null)? '' :((request.CurrentPage-1) * _top );
// -----------

// Throw Error if Mandatory Variables are empty and invalid
if(typeof custNumber ==='undefined' || custNumber ==="" || custNumber === null){
        context.setVariable("errorMessage","Invalid/Missing custNumber : "+custNumber);
        context.setVariable("validation_failed","true");
        context.setVariable("is.error",true);
        throw null;
        }
        
if(typeof suffix ==='undefined' || suffix ==="" || suffix === null){
        context.setVariable("errorMessage","Invalid/Missing suffix : "+suffix);
        context.setVariable("validation_failed","true");
        context.setVariable("is.error",true);
        throw null;
        }

        //Set Pathsuffix
            var pathSuffix_asSQLQuery ="CustNumber eq "+custNumber+" and Suffix eq "+suffix;
            
            // -----------
  if(_top !== '') pathSuffix_asSQLQuery +'&$orderby='+_top;
  if(_skip !== '') pathSuffix_asSQLQuery +'&$orderby='+_skip;
  if(_orderBy !== '') pathSuffix_asSQLQuery +'&$orderby='+_orderBy;
// -----------
            context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
            
            context.setVariable("custNumber",custNumber);
            context.setVariable("suffix",suffix);