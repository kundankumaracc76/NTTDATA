    var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){

var request= JSON.parse(req);

var company_id =request.CompanyCode;
var customer_id=request.CustNumber;
var PDFDate=request.PDFDate;

if(typeof company_id ==='undefined' || company_id ==="" || company_id === null){
 context.setVariable("errorMessage","Invalid/Missing CompanyCode : "+company_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof customer_id ==='undefined' || customer_id ==="" || customer_id === null){
 context.setVariable("errorMessage","Invalid/Missing CustNumber : "+customer_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof PDFDate ==='undefined' || PDFDate ==="" || PDFDate === null){
 context.setVariable("errorMessage","Invalid/Missing PDFDate : "+PDFDate);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;

}


}


