// Extract Mandatory Variables
var CompanyCode = context.getVariable("CompanyCode");
var CustNumber = context.getVariable("CustNumber");
var InvoiceNum = context.getVariable("InvoiceNum");

// Throw Error if Mandatory Variables are empty and invalid

if(typeof CompanyCode ==='undefined' || CompanyCode ==="" || CompanyCode === null){
        context.setVariable("errorMessage","Invalid/Missing CompanyCode : "+CompanyCode);
        context.setVariable("validation_failed","true");
        context.setVariable("is.error",true);
        throw null;
        }
        
else if(typeof CustNumber ==='undefined' || CustNumber ==="" || CustNumber === null){
        context.setVariable("errorMessage","Invalid/Missing CustNumber : "+CustNumber);
        context.setVariable("validation_failed","true");
        context.setVariable("is.error",true);
        throw null;
        }
        
else if(typeof InvoiceNum ==='undefined' || InvoiceNum ==="" || InvoiceNum === null){
        context.setVariable("errorMessage","Invalid/Missing InvoiceNum : "+InvoiceNum);
        context.setVariable("validation_failed","true");
        context.setVariable("is.error",true);
        throw null;
        }
        
else if(CompanyCode && CustNumber && InvoiceNum){
            const filterBycompanycode ="CompanyCode eq ";
            const filterBycustnumber =  ' and CustNumber eq ';
            const filterByinvoicenum =  "and InvoiceNum eq ";
            var pathSuffix_asSQLQuery = filterBycompanycode+"'"+CompanyCode+"'"+filterBycustnumber+CustNumber+filterByinvoicenum+"'"+InvoiceNum+"'";
            context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
      }
        

