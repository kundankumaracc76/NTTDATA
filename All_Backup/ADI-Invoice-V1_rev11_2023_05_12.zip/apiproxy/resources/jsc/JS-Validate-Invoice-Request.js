var itemId=context.getVariable("reqInvoice.Id");

// -----------
var _orderBy = (typeof request.Sort ==='undefined' || request.Sort ==="" || request.Sort === null)? '' : request.Sort;	
var _top = (typeof request.PageSize ==='undefined' || request.PageSize ==="" || request.PageSize === null)? '' : pageSize;
var _skip = (typeof request.CurrentPage ==='undefined' || request.CurrentPage ==="" || request.CurrentPage === null)? '' :((request.CurrentPage-1) * _top );
// -----------



if(typeof itemId === 'undefined' || itemId === null || itemId === "" || itemId === "null" || itemId.length === 0){
    context.setVariable("errorMessage","Invalid/Missing ItemId : "+itemId);
    context.setVariable("validation_failed","true");
    context.setVariable("is.error",true);
    throw null;
}
else if(itemId){
    const filterByItemId = "INVOICE_NBR eq ";
    var pathSuffix_asSQLQuery = filterByItemId+"'"+itemId+"'";
    
    // -----------
  if(_top !== '') pathSuffix_asSQLQuery +'&$top='+_top;
  if(_skip !== '') pathSuffix_asSQLQuery +'&$skip='+_skip;
  if(_orderBy !== '') pathSuffix_asSQLQuery +'&$orderby='+_orderBy;
// -----------

    context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
}


