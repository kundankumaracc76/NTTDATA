    var companyCode,invoiceNo; 
     var queryParamsList = request.queryParams;
    for(var queryParam in queryParamsList){
        switch(queryParam.toLowerCase()){
            case "compcode":
                companyCode = context.getVariable("request.queryparam." + queryParam);
                break;
            case "invoiceno":
                invoiceNo = context.getVariable("request.queryparam." + queryParam);
                break;
            }
    }
    
    // -----------
var _orderBy = (typeof request.Sort ==='undefined' || request.Sort ==="" || request.Sort === null)? '' : request.Sort;	
var _top = (typeof request.PageSize ==='undefined' || request.PageSize ==="" || request.PageSize === null)? '' : pageSize;
var _skip = (typeof request.CurrentPage ==='undefined' || request.CurrentPage ==="" || request.CurrentPage === null)? '' :((request.CurrentPage-1) * _top );
// -----------


     if(typeof companyCode ==='undefined' || companyCode===null || companyCode==='' || companyCode.length === 0){
         context.setVariable("errorMessage","Invalid/Missing CompanyCode : "+companyCode);
         context.setVariable("validation_failed","true");
         context.setVariable("is.error",true); 
         throw null;
     }
      else if(typeof invoiceNo ==='undefined' || invoiceNo===null || invoiceNo==='' || invoiceNo.length === 0){
          context.setVariable("errorMessage","Invalid/Missing InvoiceNo : "+invoiceNo);
          context.setVariable("validation_failed","true");
          context.setVariable("is.error",true);
          throw null;
      }
      else if(companyCode && invoiceNo){
            const filterByCompanyId = 'company_id eq ';
            const filterByInvoiceNo = ' and invoice_no eq ';
            var pathSuffix_asSQLQuery = filterByCompanyId+"'"+companyCode+"'"+filterByInvoiceNo+"'"+invoiceNo+"'";
           
            // -----------
  if(_top !== '') pathSuffix_asSQLQuery +'&$orderby='+_top;
  if(_skip !== '') pathSuffix_asSQLQuery +'&$orderby='+_skip;
  if(_orderBy !== '') pathSuffix_asSQLQuery +'&$orderby='+_orderBy;
// -----------

            context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
      }
      