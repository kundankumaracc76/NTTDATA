var resp = JSON.parse(context.getVariable("response.content"));

if (resp.value[0]){
var temp = [];
resp.value.forEach(function(obj) {
    temp.push(obj.invoice_date);
});

var response = {
    "CustomerSuffix": resp.value[0].ship_to_id,
    "CustNumber": resp.value[0].customer_id,
    "ReturnCode": "00",
    "ReturnMessage": "Success",
    "invlistdata": temp
};

context.setVariable("response.content", JSON.stringify(response));
}

else{
  var response = {
    "ReturnCode": "99",
    "ReturnMessage": "Error",
    "invlistdata": resp.value
};  

context.setVariable("response.content", JSON.stringify(response));
}