 var resp= JSON.parse(context.getVariable('response.content'));
var request= context.getVariable("userReq");
var multInvAgingResponse =null;
if(resp.value.length>0){
    var totGrand=0,totCurrent=0,tot01_30=0,tot31_60=0,tot61_90=0,tot90_Over=0,items =[];
     for(var obj in resp.value){
        var data=resp.value[obj];
        totGrand+=data.current_due+data.past_due_1_30+data.past_due_30_60+data.past_due_60_90+data.past_due_over90;
        totCurrent+=data.current_due;
        tot01_30+=data.past_due_1_30;
        tot31_60+=data.past_due_30_60;
        tot61_90+=data.past_due_60_90;
        tot90_Over+=data.past_due_over90;
        var item ={
           "CustomerSuffix" : data.ship_to_id,
           "City" : data.city,
           "State" : data.state,
           "CurAmount" : data.current_due,
           "Tot01_30" : data.past_due_1_30,
           "Tot31_60" : data.past_due_30_60,
           "Tot61_90" : data.past_due_60_90,
           "Tot90_Over" : data.past_due_over90
        };
       items.push(item);
     }
 multInvAgingResponse ={
         "CustNumber" : resp.value[0].customer_id,
         "CurDate" : request.CurDate?request.CurDate:"",
         "CurPage" : request.CurPage?request.CurPage:0,
         "LastPage" : request.LastPage?request.LastPage:0,
         "TotRecords" : resp.value.length,
         "TotGrand" : totGrand,
         "TotCurrent" : totCurrent ,
         "Tot01_30" : tot01_30,
         "Tot31_60" : tot31_60,
         "Tot61_90" : tot61_90,  
         "Tot90_Over" : tot90_Over,
         "ReturnCode" : "00",
         "invlineitem" : items
     };
}else if(resp.value.length === 0){ 
    multInvAgingResponse = {
        "CustNumber" : request.CustNumber,
        "CurDate" : request.CurDate,
        "LastPage" : 0,
        "TotRecords" : 0,
        "TotGrand" : 0,
        "TotCurrent" : 0,
        "Tot01_30" : 0,
        "Tot31_60" : 0,
        "Tot61_90" : 0,
        "Tot90_Over" : 0,
        "ReturnCode" : "00",
        "ReturnMessage" : "No Record Found.",
        "invlineitem" : []
  };
}
context.setVariable("response.content",JSON.stringify(multInvAgingResponse));   
context.setVariable("response.header.X-TransactionId",context.getVariable('transactionID'));