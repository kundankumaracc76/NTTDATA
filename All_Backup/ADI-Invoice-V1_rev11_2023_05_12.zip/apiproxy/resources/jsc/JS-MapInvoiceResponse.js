var resp= JSON.parse(context.getVariable("response.content"));

var compCode = context.getVariable("request.queryparam.compCode");
var invoiceNo = context.getVariable("request.queryparam.invoiceNo");



var invoiceResponse;
if(resp.value.length > 0){
    var value=resp.value[0];
 invoiceResponse={
    "CompanyCode" : value.company_id,
    "InvoiceNo" : value.invoice_no,
    "CustomerSuffix" : null,
    "CustNumber" : null,
    "ReturnCode" : "00",
    "ReturnMessage" :"Success",
    "Encoding" : value.encoding,
    "ReturnSignData" : value.ReturnSignData
    
};
} else if(resp.value.length===0){
invoiceResponse ={
   "CompanyCode":compCode,
   "InvoiceNo":invoiceNo,
   "CustomerSuffix": null,
   "CustNumber": null,
   "ReturnCode":"00",
   "ReturnMessage":"Success.",
   "Encoding":"",
   "ReturnSignData":""
};
}


context.setVariable("response.content",JSON.stringify(invoiceResponse));
context.setVariable("response.header.X-TransactionId",context.getVariable('transactionID'));