 var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null;
 }else if(req){

var invReq= JSON.parse(req);

// Extract Mandatory Variables
var MajorVersion = invReq.GetCartSummary.Request.B2BSellerVersion.MajorVersion;
var MinorVersion = invReq.GetCartSummary.Request.B2BSellerVersion.MinorVersion;
var BuildNumber = invReq.GetCartSummary.Request.B2BSellerVersion.BuildNumber;
var StoreName  =  invReq.GetCartSummary.Request.StoreName;
var CustomerCode = invReq.GetCartSummary.Request.CustomerCode;
var ShipToID =  invReq.GetCartSummary.Request.ShipToID;
var WebReferenceNumber = invReq.GetCartSummary.Request.WebReferenceNumber;
var LineItem = invReq.GetCartSummary.Request.ListOfLineItems.LineItem;


// Array Declaration for mandatory fields
var MajorVersion_Check = ["5"];
var MinorVersion_Check = ["11"];
var BuildNumber_Check = ["145"];

// Condition to check if mandatory values are not null and empty
if(typeof MajorVersion ==='undefined' || MajorVersion ==="" || MajorVersion === null){
 context.setVariable("errorMessage","Missing MajorVersion : "+MajorVersion);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof MinorVersion ==='undefined' || MinorVersion ==="" || MinorVersion === null){
 context.setVariable("errorMessage","Missing MinorVersion : "+MinorVersion);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof BuildNumber ==='undefined' || BuildNumber ==="" || BuildNumber === null){
 context.setVariable("errorMessage","Missing BuildNumber : "+BuildNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof StoreName ==='undefined' || StoreName ==="" || StoreName === null){
 context.setVariable("errorMessage","Missing StoreName : "+StoreName);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof CustomerCode ==='undefined' || CustomerCode ==="" || CustomerCode === null){
 context.setVariable("errorMessage","Missing CustomerCode : "+CustomerCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof ShipToID ==='undefined' || ShipToID ==="" || ShipToID === null){
 context.setVariable("errorMessage","Missing ShiptoId : "+ShipToID);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof WebReferenceNumber ==='undefined' || WebReferenceNumber ==="" || WebReferenceNumber === null){
 context.setVariable("errorMessage","Missing WebReferenceNumber : "+WebReferenceNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof LineItem ==='undefined' || LineItem ==="" || LineItem === null){
 context.setVariable("errorMessage","Missing LineItem : "+LineItem);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

// Mandatory Params value check code
else if(!(isInArray(MinorVersion, MinorVersion_Check))){
 context.setVariable("errorMessage","Invalid MinorVersion  : "+MinorVersion);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(!(isInArray(MajorVersion, MajorVersion_Check))){
 context.setVariable("errorMessage","Invalid MajorVersion  : "+MajorVersion);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(!(isInArray(BuildNumber, BuildNumber_Check))){
 context.setVariable("errorMessage","Invalid BuildNumber  : "+BuildNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

}

// Function to check values of mandatory parameters
function isInArray(value, array) {
  return array.indexOf(value) > -1;
}


