var res= JSON.parse(context.getVariable("response.content"));
var rtnCode = res.GetCartSummary.ReplyStatus.Result;
rtnCode = (rtnCode==='0'||rtnCode===0)? '00':'99';
var rtnMessage = res.GetCartSummary.ReplyStatus.Message;
rtnMessage = (rtnCode==='00')?'Success':rtnMessage;
var webres = {
    "GetCartSummary": {
        "Reply": res.GetCartSummary.Reply,
        "ReplyStatus": res.GetCartSummary.ReplyStatus,
        "ReturnCode":rtnCode,
        "ReturnMsg":rtnMessage,
    }
};
context.setVariable("response.content",JSON.stringify(webres));


