var resp = JSON.parse(context.getVariable("response.content"));

// Check if card details returned by P21
if (resp.value[0]){
var masked_card_no = resp.value[0].masked_card_no;

//Frame Success response to website
var getccresp = [
            {
              "cardType": resp.value[0].associated_payment_type,
             // "cardNumber": masked_card_no.replace('***********', ''),
              "cardNumber": masked_card_no,
              "cardToken": resp.value[0].token_id,
              "expiryMonth": resp.value[0].expiration_date.split("-")[1],
              "expiryYear": resp.value[0].expiration_date.split("-")[0]
            },
            {
                "ResponseCode": "00",
                "ResponseMsg": "Success"
            }
];

//Setting response
context.setVariable("response.content", JSON.stringify(getccresp));
}

else {
    //Setting failure response body to website
    var getccresp = [
            {
                "Message": "Requested Card Not Found",
                "ResponseCode": "99",
                "ResponseMsg": "Failed"
            }
        ];
        
    //Setting response
context.setVariable("response.content", JSON.stringify(getccresp));
}
