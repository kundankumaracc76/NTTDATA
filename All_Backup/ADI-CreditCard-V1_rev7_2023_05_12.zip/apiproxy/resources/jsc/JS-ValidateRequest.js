var pathsuffix= context.getVariable("proxy.pathsuffix");

function isInArray(value, array) {
  return array.indexOf(value) > -1;
}

// validate request if not null
if (pathsuffix !== "/list"){
var req= context.getVariable("request.content");

 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){

// parse request json
var request= JSON.parse(req);

// condition to check if path suffix is /update
if (pathsuffix === "/update"){
    var PaymentAccountUid=request.PaymentAccountUid;
    var ExpirationDate=request.ExpirationDate;
    var SetDefault=request.SetDefault;
    
// check manadatory param if not null and valid
if(typeof PaymentAccountUid ==='undefined' || PaymentAccountUid ==="" || PaymentAccountUid === null){
 context.setVariable("errorMessage","Invalid/Missing PaymentAccountUid : "+PaymentAccountUid);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
if(typeof ExpirationDate ==='undefined' || ExpirationDate ==="" || ExpirationDate === null){
 context.setVariable("errorMessage","Invalid/Missing ExpirationDate : "+ExpirationDate);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
if(typeof SetDefault ==='undefined' || SetDefault ==="" || SetDefault === null){
 context.setVariable("errorMessage","Invalid/Missing SetDefault : "+SetDefault);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }

}

// condition to check if path suffix is /list
if (pathsuffix === "/list"){
    var PaymentAccountUid=request.PaymentAccountUid;
    var ExpirationDate=request.ExpirationDate;
    var SetDefault=request.SetDefault;
    
// check manadatory param if not null and valid
if(typeof PaymentAccountUid ==='undefined' || PaymentAccountUid ==="" || PaymentAccountUid === null){
 context.setVariable("errorMessage","Invalid/Missing PaymentAccountUid : "+PaymentAccountUid);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
if(typeof ExpirationDate ==='undefined' || ExpirationDate ==="" || ExpirationDate === null){
 context.setVariable("errorMessage","Invalid/Missing ExpirationDate : "+ExpirationDate);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
if(typeof SetDefault ==='undefined' || SetDefault ==="" || SetDefault === null){
 context.setVariable("errorMessage","Invalid/Missing SetDefault : "+SetDefault);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }

}

// condition to check if path suffix is /add
if (pathsuffix === "/add"){
var CompanyId=request.CompanyId;
var ContactId=request.ContactId;
var CustomerId=request.CustomerId;
var ShipToId=request.ShipToId;
var PaymentTypeId=request.PaymentTypeId;
var TokenId=request.TokenId;
var ExpirationDate=request.ExpirationDate;
var MaskedCardNumber=request.MaskedCardNumber;
var SetDefault=request.SetDefault;
var Description=request.Description;

// extract month and date
var expiryMonth = ExpirationDate.split("-")[1];
var expiryYear = ExpirationDate.split("-")[0];
var expiryDate = ExpirationDate.split("-")[2].split("T")[0];
var time = ExpirationDate.split("-")[2].split("T")[1];

// Array check for 31 or 30 month
var thirtydays_array = ["04","06","09","11"];
var feb_month = ["02"];

if((isInArray(expiryMonth, thirtydays_array))){
  var expiryDate = "30";
}
else if (isInArray(expiryMonth, feb_month)){
  var expiryDate = "28";
}
else{
  var expiryDate = "31";
}

var ExpirationDate = expiryYear+'-'+expiryMonth+'-'+expiryDate+"T"+time;
request.ExpirationDate = ExpirationDate;
context.setVariable("request.content",JSON.stringify(request));

// check manadatory param if not null and valid
if(typeof CompanyId ==='undefined' || CompanyId ==="" || CompanyId === null){
 context.setVariable("errorMessage","Invalid/Missing CompanyId : "+CompanyId);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
if(typeof ContactId ==='undefined' || ContactId ==="" || ContactId === null){
    if(typeof CustomerId ==='undefined' || CustomerId ==="" || CustomerId === null){
        if(typeof ShipToId ==='undefined' || ShipToId ==="" || ShipToId === null){
                    context.setVariable("errorMessage","Atlease one param should be present : ContactId or CustomerId or ShipToId || Values Recieved - ContactId "+ContactId+" :CustomerId "+CustomerId+" :ShipToId "+ShipToId);
                    context.setVariable("validation_failed","true");
                    context.setVariable("is.error",true);
                    throw null;
                }
            }   
    }   
if(typeof PaymentTypeId ==='undefined' || PaymentTypeId ==="" || PaymentTypeId === null){
 context.setVariable("errorMessage","Invalid/Missing PaymentTypeId : "+PaymentTypeId);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
if(typeof TokenId ==='undefined' || TokenId ==="" || TokenId === null){
 context.setVariable("errorMessage","Invalid/Missing TokenId : "+TokenId);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
if(typeof ExpirationDate ==='undefined' || ExpirationDate ==="" || ExpirationDate === null){
 context.setVariable("errorMessage","Invalid/Missing ExpirationDate : "+ExpirationDate);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
if(typeof MaskedCardNumber ==='undefined' || MaskedCardNumber ==="" || MaskedCardNumber === null){
 context.setVariable("errorMessage","Invalid/Missing MaskedCardNumber : "+MaskedCardNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
    }
if(typeof SetDefault ==='undefined' || SetDefault ==="" || SetDefault === null){
 context.setVariable("errorMessage","Invalid/Missing SetDefault : "+SetDefault);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
  throw null;
    }
if(typeof Description ==='undefined' || Description ==="" || Description === null){
 context.setVariable("errorMessage","Invalid/Missing Description : "+Description);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
  throw null;
    }

  }

}
}


if (pathsuffix === "/list"){
    var customer_id = context.getVariable("request.queryparam.custNumber");
    var contact_id = context.getVariable("request.queryparam.suffix");
    var company_id = context.getVariable("request.queryparam.compCode");
    var stored = context.getVariable("request.queryparam.storedOn");
    
    
    if (stored === "Customer"){
        if(typeof customer_id ==='undefined' || customer_id ==="" || customer_id === null){
        context.setVariable("errorMessage","Invalid/Missing custNumber : "+customer_id);
        context.setVariable("validation_failed","true");
        context.setVariable("is.error",true);
        throw null;
        }
    
    if(typeof company_id ==='undefined' || company_id ==="" || company_id === null){
        context.setVariable("errorMessage","Invalid/Missing compCode : "+company_id);
        context.setVariable("validation_failed","true");
        context.setVariable("is.error",true);
        throw null;
            }
    
            var pathSuffix_asSQLQuery = "stored_on eq 'Customer' and customer_id eq "+customer_id+" and company_id eq "+"'"+company_id+"'";
            context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
            context.removeVariable("request.queryparam.custNumber");
            context.removeVariable("request.queryparam.suffix");
            context.removeVariable("request.queryparam.compCode");
            context.removeVariable("request.queryparam.storedOn");
    }
    
    if (stored === "Ship To"){
        if(typeof contact_id ==='undefined' || contact_id ==="" || contact_id === null){
            context.setVariable("errorMessage","Invalid/Missing suffix : "+contact_id);
            context.setVariable("validation_failed","true");
            context.setVariable("is.error",true);
            throw null;
            }
    
         if(typeof company_id ==='undefined' || company_id ==="" || company_id === null){
            context.setVariable("errorMessage","Invalid/Missing compCode : "+company_id);
            context.setVariable("validation_failed","true");
            context.setVariable("is.error",true);
            throw null;
            }
            var pathSuffix_asSQLQuery = "stored_on eq 'Ship To' and ship_to_id eq "+contact_id+" and company_id eq "+"'"+company_id+"'";
            context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
            context.removeVariable("request.queryparam.custNumber");
            context.removeVariable("request.queryparam.suffix");
            context.removeVariable("request.queryparam.compCode");
            context.removeVariable("request.queryparam.storedOn");
    }
}

