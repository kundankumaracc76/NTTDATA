var resp = JSON.parse(context.getVariable("response.content"));

var resObj=[];

for (var i = 0; i < resp.value.length; i++) {
 temp = 
        {
					"id": resp.value[i].payment_account_uid,
					"cardType": resp.value[i].associated_payment_type,
					"cardNumber": resp.value[i].masked_card_no,
					"cardToken": resp.value[i].token_id,
					"expiryMonth": resp.value[i].expiration_date.split("-")[1],
					"expiryYear": resp.value[i].expiration_date.split("-")[0]
				};

resObj.push(temp);
}

context.setVariable("response.content",JSON.stringify(resObj));