var resp = JSON.parse(context.getVariable("response.content"));

// Modify Response of other API Calls
    if (resp.Result != -1){
        var othercall_response = {
        "StoredPaymentAccountOperationResult": resp,
        "ResponseCode": "00",
        "ResponseMsg": "Success"
        };
    context.setVariable("response.content", JSON.stringify(othercall_response));
    }
    else {
        var othercall_response = {
        "StoredPaymentAccountOperationResult": resp,
        "ResponseCode": "99",
        "ResponseMsg": "Failed"
        };
    context.setVariable("response.content", JSON.stringify(othercall_response));
    } 
    