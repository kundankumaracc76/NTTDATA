  var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){

var request= JSON.parse(req);

const filterByOrdernumber ='orderNumber  eq ';
const filterBycustnumber =  ' and CustNumber eq ';
const filterByShiptoId =  ' and ship_to_id eq ';

var CustNumber=request.CustomerNumber;
var ship_to_id=request.CustomerSuffix;
var orderNumber1=request.Orders[0];
var orderNumber2=request.Orders[1];
var CompCode=request.CompanyCode;


 
 if(typeof CustNumber ==='undefined' || CustNumber ==="" || CustNumber === null){
 context.setVariable("errorMessage","Invalid/Missing CustomerNumber : "+CustNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ship_to_id ==='undefined' || ship_to_id ==="" || ship_to_id === null){
 context.setVariable("errorMessage","Invalid/Missing CustomerSuffix : "+ship_to_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof orderNumber1 ==='undefined' || orderNumber1 ==="" || orderNumber1 === null){
 context.setVariable("errorMessage","Invalid/Missing Orders : "+orderNumber1);
 context.setVariable("validation_failed","true");""
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof orderNumber2 ==='undefined' || orderNumber2 ==="" || orderNumber2 === null){
 context.setVariable("errorMessage","Invalid/Missing Orders : "+orderNumber2);
 context.setVariable("validation_failed","true");""
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof CompCode ==='undefined' || CompCode ==="" || CompCode === null){
 context.setVariable("errorMessage","Invalid/Missing CompanyCode : "+CompCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}


}

var pathSuffix_asSQLQuery = "("+filterByOrdernumber+"'"+orderNumber1+"' or "+filterByOrdernumber+"'"+orderNumber2+"')"+filterBycustnumber+CustNumber+filterByShiptoId+ship_to_id;
context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
print("pathSuffix_asSQLQuery->",pathSuffix_asSQLQuery)
