  var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){

var request= JSON.parse(req);

const filterByCmmOrderNbr ="CMM_ORDER_NBR eq ";
const filterByCustomerId =  ' and customer_id eq ';
const filterByShiptoId =  ' and ship_to_id eq ';

var customer_id=request.Cust_Number;
var ship_to_id=request.Cust_Suffix;
var CMM_ORDER_NBR=request.OrderNumber;


 
 if(typeof customer_id ==='undefined' || customer_id ==="" || customer_id === null){
 context.setVariable("errorMessage","Invalid/Missing Cust_Number : "+customer_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ship_to_id ==='undefined' || ship_to_id ==="" || ship_to_id === null){
 context.setVariable("errorMessage","Invalid/Missing Cust_Suffix : "+ship_to_id);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof CMM_ORDER_NBR ==='undefined' || CMM_ORDER_NBR ==="" || CMM_ORDER_NBR === null){
 context.setVariable("errorMessage","Invalid/Missing OrderNumber : "+CMM_ORDER_NBR);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}


}

var pathSuffix_asSQLQuery = filterByCmmOrderNbr+"'"+CMM_ORDER_NBR+"'"+filterByCustomerId+customer_id+filterByShiptoId+ship_to_id;
context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
print("pathSuffix_asSQLQuery->",pathSuffix_asSQLQuery)
