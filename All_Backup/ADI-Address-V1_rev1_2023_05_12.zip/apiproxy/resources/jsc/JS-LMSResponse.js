var resp = JSON.parse(context.getVariable("response.content"));

// Validate and csutomise response sent to website
if(resp.Document.Addresses[0]){
    var success_resp = {
                "Addresses": resp.Document.Addresses,
                "returnCode":"00",
                "returnMessage":"Success"
        };
        
 context.setVariable("response.content",JSON.stringify(success_resp));
}

else{
   var error_resp = {
                "customer": null,
                "returnCode":"99",
                "returnMessage": resp.ErrorText
        };
    context.setVariable("response.content",JSON.stringify(error_resp)); 
}

