var AccessRequestJson = {
	"AccessRequest": {
		"AccessLicenseNumber": "ACD96930CD5A6A96",
		"UserId": "ADItest1",
		"Password": "testADI1"
	}
}
context.setVariable("AccessRequestJson",JSON.stringify(AccessRequestJson));