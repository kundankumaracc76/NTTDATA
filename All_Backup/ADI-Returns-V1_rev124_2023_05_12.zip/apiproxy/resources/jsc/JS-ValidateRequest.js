 var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){

var requestdata= JSON.parse(req);


var CustomerContext=requestdata.Request.TransactionReference.CustomerContext;
var Description=requestdata.Shipment.Description;
var Shipper=requestdata.Shipment.Shipper;
var Name=requestdata.Shipment.Shipper.Name;
var ShipperNumber=requestdata.Shipment.Shipper.ShipperNumber;
var ShipperAddressLine1=requestdata.Shipment.Shipper.Address.AddressLine1;
var ShipperCity=requestdata.Shipment.Shipper.Address.City;
var ShipperStateProvinceCode=requestdata.Shipment.Shipper.Address.StateProvinceCode;
var ShipperPostalCode=requestdata.Shipment.Shipper.Address.PostalCode;
var ShipperCountryCode=requestdata.Shipment.Shipper.Address.CountryCode;
var ShipToCompanyName=requestdata.Shipment.ShipTo.CompanyName;
var ShipToAddressLine1=requestdata.Shipment.ShipTo.Address.AddressLine1;
var ShipToCity=requestdata.Shipment.ShipTo.Address.City;
var ShipToStateProvinceCode=requestdata.Shipment.ShipTo.Address.StateProvinceCode;
var ShipToPostalCode=requestdata.Shipment.ShipTo.Address.PostalCode;
var ShipToCountryCode=requestdata.Shipment.ShipTo.Address.CountryCode;
var ShipFromCompanyName=requestdata.Shipment.ShipFrom.CompanyName;
var ShipFromAddressLine1=requestdata.Shipment.ShipFrom.Address.AddressLine1;
var ShipFromCity=requestdata.Shipment.ShipFrom.Address.City;
var ShipFromStateProvinceCode=requestdata.Shipment.ShipFrom.Address.StateProvinceCode;
var ShipFromPostalCode=requestdata.Shipment.ShipFrom.Address.PostalCode;
var ShipFromCountryCode=requestdata.Shipment.ShipFrom.Address.CountryCode;
var AccountNumber=requestdata.Shipment.PaymentInformation.AccountNumber;
var Value=requestdata.Shipment.Package[0].ReferenceNumber.Value;
var UnitOfMeasurement=requestdata.Shipment.Package[0].PackageWeight.UnitOfMeasurement;
var Weight=requestdata.Shipment.Package[0].PackageWeight.Weight;



 if(typeof CustomerContext ==='undefined' || CustomerContext ==="" || CustomerContext === null){
 context.setVariable("errorMessage","Invalid/Missing CustomerContext : "+CustomerContext);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof Description ==='undefined' || Description ==="" || Description === null){
 context.setVariable("errorMessage","Invalid/Missing Description : "+Description);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof Shipper ==='undefined' || Shipper ==="" || Shipper === null){
 context.setVariable("errorMessage","Invalid/Missing Shipper : "+Shipper);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof Name ==='undefined' || Name ==="" || Name === null){
 context.setVariable("errorMessage","Invalid/Missing Name : "+Name);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;

}else if(typeof ShipperNumber ==='undefined' || ShipperNumber ==="" || ShipperNumber === null){
 context.setVariable("errorMessage","Invalid/Missing ShipperNumber : "+ShipperNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipperAddressLine1 ==='undefined' || ShipperAddressLine1 ==="" || ShipperAddressLine1 === null){
 context.setVariable("errorMessage","Invalid/Missing AddressLine1 : "+ShipperAddressLine1);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
 
}else if(typeof ShipperCity ==='undefined' || ShipperCity ==="" || ShipperCity === null){
 context.setVariable("errorMessage","Invalid/Missing City : "+ShipperCity);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipperStateProvinceCode ==='undefined' || ShipperStateProvinceCode ==="" || ShipperStateProvinceCode === null){
 context.setVariable("errorMessage","Invalid/Missing StateProvinceCode : "+ShipperStateProvinceCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipperPostalCode ==='undefined' || ShipperPostalCode ==="" || ShipperPostalCode === null){
 context.setVariable("errorMessage","Invalid/Missing PostalCode : "+ShipperPostalCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipperCountryCode ==='undefined' || ShipperCountryCode ==="" || ShipperCountryCode === null){
 context.setVariable("errorMessage","Invalid/Missing CountryCode : "+ShipperCountryCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;

}else if(typeof ShipToCompanyName ==='undefined' || ShipToCompanyName ==="" || ShipToCompanyName === null){
 context.setVariable("errorMessage","Invalid/Missing CompanyName : "+ShipToCompanyName);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipToAddressLine1 ==='undefined' || ShipToAddressLine1 ==="" || ShipToAddressLine1 === null){
 context.setVariable("errorMessage","Invalid/Missing AddressLine1 : "+ShipToAddressLine1);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
 
}else if(typeof ShipToCity ==='undefined' || ShipToCity ==="" || ShipToCity === null){
 context.setVariable("errorMessage","Invalid/Missing City : "+ShipToCity);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipToStateProvinceCode ==='undefined' || ShipToStateProvinceCode ==="" || ShipToStateProvinceCode === null){
 context.setVariable("errorMessage","Invalid/Missing StateProvinceCode : "+ShipToStateProvinceCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipToPostalCode ==='undefined' || ShipToPostalCode ==="" || ShipToPostalCode === null){
 context.setVariable("errorMessage","Invalid/Missing PostalCode : "+ShipToPostalCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipToCountryCode ==='undefined' || ShipToCountryCode ==="" || ShipToCountryCode === null){
 context.setVariable("errorMessage","Invalid/Missing CountryCode : "+ShipToCountryCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipFromCompanyName ==='undefined' || ShipFromCompanyName ==="" || ShipFromCompanyName === null){
 context.setVariable("errorMessage","Invalid/Missing CompanyName : "+ShipFromCompanyName);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipFromAddressLine1 ==='undefined' || ShipFromAddressLine1 ==="" || ShipFromAddressLine1 === null){
 context.setVariable("errorMessage","Invalid/Missing AddressLine1 : "+ShipFromAddressLine1);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
 
}else if(typeof ShipFromCity ==='undefined' || ShipFromCity ==="" || ShipFromCity === null){
 context.setVariable("errorMessage","Invalid/Missing City : "+ShipFromCity);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipFromStateProvinceCode ==='undefined' || ShipFromStateProvinceCode ==="" || ShipFromStateProvinceCode === null){
 context.setVariable("errorMessage","Invalid/Missing StateProvinceCode : "+ShipFromStateProvinceCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipFromPostalCode ==='undefined' || ShipFromPostalCode ==="" || ShipFromPostalCode === null){
 context.setVariable("errorMessage","Invalid/Missing PostalCode : "+ShipFromPostalCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;

}else if(typeof ShipFromCountryCode ==='undefined' || ShipFromCountryCode ==="" || ShipFromCountryCode === null){
 context.setVariable("errorMessage","Invalid/Missing CountryCode : "+ShipFromCountryCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof AccountNumber ==='undefined' || AccountNumber ==="" || AccountNumber === null){
 context.setVariable("errorMessage","Invalid/Missing AccountNumber : "+AccountNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;

}else if(typeof Value ==='undefined' || Value ==="" || Value === null){
 context.setVariable("errorMessage","Invalid/Missing Value : "+Value);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof UnitOfMeasurement ==='undefined' || UnitOfMeasurement ==="" || UnitOfMeasurement === null){
 context.setVariable("errorMessage","Invalid/Missing UnitOfMeasurement : "+UnitOfMeasurement);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof Weight ==='undefined' || Weight ==="" || Weight === null){
 context.setVariable("errorMessage","Invalid/Missing Weight : "+Weight);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}

 
}

