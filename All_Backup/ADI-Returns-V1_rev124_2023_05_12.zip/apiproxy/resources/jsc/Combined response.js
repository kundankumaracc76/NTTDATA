 // Pros Response
var shipconfirmresp = JSON.parse(context.getVariable("scshipconfirmResponse.content"));
// Investory Response
var shipacceptresp = JSON.parse(context.getVariable("scshipacceptResponse.content"));

var respcombine = {
    "ShipmentConfirmResponse": shipconfirmresp.ShipmentConfirmResponse,
    "ShipmentAcceptResponse": shipacceptresp.ShipmentAcceptResponse
};
context.setVariable("response.content",JSON.stringify(respcombine));

