var req = JSON.parse(context.getVariable("request.content"));
var expected_json_format_target_request = {
	"ShipmentAcceptRequest": {
		"Request": {
			"TransactionReference": {
				"CustomerContext": req.TransactionReference
			},
			"RequestAction": "ShipAccept"
		},
		"ShipmentDigest": req.ShipmentDigest
	}
 }
context.setVariable("expected_json_format_target_request",JSON.stringify(expected_json_format_target_request));
print("expected_json_format_target_request",JSON.stringify(expected_json_format_target_request))
/*

var expected_xml_format_target_request = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><ShipmentAcceptRequest><Request><TransactionReference><CustomerContext>{{CustomerContext}}</CustomerContext></TransactionReference><RequestAction>ShipAccept</RequestAction></Request><ShipmentDigest>{{ShipmentDigest}}</ShipmentDigest></ShipmentAcceptRequest>";
expected_xml_format_target_request = expected_xml_format_target_request.replace("{{CustomerContext}}",req.TransactionReference);
expected_xml_format_target_request = expected_xml_format_target_request.replace("{{ShipmentDigest}}",req.ShipmentDigest);
context.setVariable("expected_xml_format_target_request",expected_xml_format_target_request);
*/