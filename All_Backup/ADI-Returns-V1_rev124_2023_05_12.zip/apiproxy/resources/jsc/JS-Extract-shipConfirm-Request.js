var req = JSON.parse(context.getVariable("request.content"));

var expected_json_format_target_request = {
  "ShipmentConfirmRequest": {
    "Request": {
      "TransactionReference": {
        "CustomerContext": req.Request.TransactionReference.CustomerContext
      },
      "RequestAction": "ShipConfirm",
      "RequestOption": "nonvalidate"
    },
    "LabelSpecification": {
      "LabelPrintMethod": {
        "Code": "EPL"
      },
      "LabelStockSize": {
        "Height": 4,
        "Width": 6
      }
    },
    "Shipment": {
      "Description": req.Shipment.Description,
      "Shipper": req.Shipment.Shipper,
      "ShipTo": req.Shipment.ShipTo,
      "ShipFrom": req.Shipment.ShipFrom,
      "PaymentInformation": {
				"BillThirdParty": {
					"BillThirdPartyShipper": {
						"AccountNumber": "23X755",
						"ThirdParty": {
							"Address": {
								"PostalCode": "23150",
								"CountryCode": "US"
							}
						}
					}
				}
			},
      "Service": {
        "Code": "03",
        "Description": "UPS GROUND"
      },
      "ShipmentServiceOptions": {
        "LabelDelivery": {
          "LabelLinksIndicator": "Y"
        },
        "Notification": {
          "NotificationCode": 6
        }
      },
      "Package": []
    }
  }
};

function pkgItems(pkg){
    expected_json_format_target_request.ShipmentConfirmRequest.Shipment.Package.push({
          "ReferenceNumber": {
            "BarCodeIndicator": "Y",
            "Code": "TN",
            "Value": pkg.ReferenceNumber.Value
          },
          "PackagingType": {
            "Code": "02"
          },
          "PackageWeight": {
            "UnitOfMeasurement": pkg.PackageWeight.UnitOfMeasurement,
            "Weight": pkg.PackageWeight.Weight
          }
        });
}

req.Shipment.Package.forEach(pkgItems);
context.setVariable("expected_json_format_target_request",JSON.stringify(expected_json_format_target_request));



