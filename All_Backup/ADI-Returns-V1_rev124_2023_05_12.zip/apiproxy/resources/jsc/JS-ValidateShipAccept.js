 var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){

var requestdata= JSON.parse(req);


//var TransactionReference = requestdata.TransactionReference.CustomerContext;
var TransactionReference = requestdata.TransactionReference;
var ShipmentDigest=requestdata.ShipmentDigest;



 if(typeof TransactionReference ==='undefined' || TransactionReference ==="" || TransactionReference === null){
 context.setVariable("errorMessage","Invalid/Missing TransactionReference : "+TransactionReference);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof ShipmentDigest ==='undefined' || ShipmentDigest ==="" || ShipmentDigest === null){
 context.setVariable("errorMessage","Invalid/Missing ShipmentDigest : "+ShipmentDigest);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 

}

 
}

