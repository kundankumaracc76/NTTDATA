  var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){

var request= JSON.parse(req);

const filterByrmareturnid ="RMAReturnID eq ";

var RMAReturnID=request.ReturnID;

if(typeof RMAReturnID ==='undefined' || RMAReturnID ==="" || RMAReturnID === null){
 context.setVariable("errorMessage","Invalid/Missing ReturnID : "+RMAReturnID);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null; 
  }
}

var pathSuffix_asSQLQuery = filterByrmareturnid+"'"+RMAReturnID+"'";
context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
print("pathSuffix_asSQLQuery->",pathSuffix_asSQLQuery)
