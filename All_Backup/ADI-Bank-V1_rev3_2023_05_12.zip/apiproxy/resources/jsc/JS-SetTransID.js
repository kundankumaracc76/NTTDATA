  var trackingId = null;
var transactionId = context.getVariable("request.header.X-TransactionId");
if(transactionId === 'undefined' || transactionId === null || transactionId === '')
  trackingId = context.getVariable("systemGeneratedTrackingId");
  else trackingId = transactionId;
context.setVariable("transactionID",trackingId);