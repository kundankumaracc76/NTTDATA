 var resp = JSON.parse(context.getVariable("response.content"));

// Orchestrate APIGEE response as per status from P21 response
if(resp.Summary.Succeeded == 1){
    var success_resp = {
                    "ReturnCode": "00",
                    "ReturnMessage": "Success",
                    "ReturnLocation": resp.Messages
                };
        
    context.setVariable("response.content",JSON.stringify(success_resp));
}

else{
   var error_resp = {
                    "ReturnCode": "99",
                    "ReturnMessage": "Error",
                    "ReturnLocation": resp.Messages
                };
                
    context.setVariable("response.content",JSON.stringify(error_resp)); 
}

