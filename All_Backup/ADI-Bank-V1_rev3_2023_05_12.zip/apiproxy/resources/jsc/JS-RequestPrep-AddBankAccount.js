 var req = JSON.parse(context.getVariable("request.content"));

// framing target request from value extracted from request body
var targetReq = {
    "Name": "Customer",
    "Transactions": [
        {
            "Status": "New",
            "DataElements": [
                {
                    "Name": "TABPAGE_1.tp_1_dw_1",
                    "Type": "Form",
                    "Rows": [
                        {
                            "Edits": [
                                {
                                    "Name": "company_id",
                                    "Value": "412"
                                },
                                {
                                    "Name": "customer_id",
                                    "Value": req.CustomerNumber
                                }
                            ]
                        }
                    ]
                },
                {
                    "Name": "TP_EFT.eft",
                    "Type": "List",
                    "Rows": [
                        {
                            "Edits": [
                                {
                                    "Name": "Bank",
                                    "Value": req.AccountDescription
                                },
                                {
                                    "Name": "account_number",
                                    "Value": req.AccountNumber
                                },
                                {
                                    "Name": "routing_number",
                                    "Value": req.AccountRoutingNumber
                                },
                                {
                                    "Name": "status",
                                    "Value": "N"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
};

// Setting orchestrated Request onto flow valriable.
context.setVariable("request.content",JSON.stringify(targetReq));
