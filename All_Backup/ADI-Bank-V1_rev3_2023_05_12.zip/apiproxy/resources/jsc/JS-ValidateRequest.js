  var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null; 
 }else if(req){

var request= JSON.parse(req);

 const filterByCompanyId ="company_id eq ";
 const filterByCustomerId =  ' and customer_id eq ';

var CompanyCode=request.CompanyCode;
var CustomerNmNo=request.CustomerNmNo;
var RequestID=request.RequestID;
var CustomerSuffix=request.CustomerSuffix;
 context.setVariable("CustomerSuffix",CustomerSuffix);
 
 // -----------
var _orderBy = (typeof request.Sort ==='undefined' || request.Sort ==="" || request.Sort === null)? '' : request.Sort;	
var _top = (typeof request.PageSize ==='undefined' || request.PageSize ==="" || request.PageSize === null)? '' : pageSize;
var _skip = (typeof request.CurrentPage ==='undefined' || request.CurrentPage ==="" || request.CurrentPage === null)? '' :((request.CurrentPage-1) * _top );
// -----------

if(typeof CompanyCode ==='undefined' || CompanyCode ==="" || CompanyCode === null){
 context.setVariable("errorMessage","Invalid/Missing CompanyCode : "+CompanyCode);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof CustomerNmNo ==='undefined' || CustomerNmNo ==="" || CustomerNmNo === null){
 context.setVariable("errorMessage","Invalid/Missing CustomerNmNo : "+CustomerNmNo);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
 
}else if(typeof RequestID ==='undefined' || RequestID ==="" || RequestID === null){
 context.setVariable("errorMessage","Invalid/Missing RequestID : "+RequestID);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

}

  var pathSuffix_asSQLQuery = filterByCompanyId+"'"+CompanyCode+"'"+filterByCustomerId+CustomerNmNo;
  
  // -----------
  if(_top !== '') pathSuffix_asSQLQuery +'&$orderby='+_top;
  if(_skip !== '') pathSuffix_asSQLQuery +'&$orderby='+_skip;
  if(_orderBy !== '') pathSuffix_asSQLQuery +'&$orderby='+_orderBy;
// -----------

  context.setVariable("targetPathSuffix",pathSuffix_asSQLQuery);
  print("pathSuffix_asSQLQuery->",pathSuffix_asSQLQuery)
