var req= context.getVariable("request.content");
 if(typeof req==='undefined' || req===null || req===''){
     context.setVariable("errorMessage","The server cannot or will not process the request due to an apparent client error.");
     context.setVariable("validation_failed","true");
     context.setVariable("is.error",true);
     throw null;
 }else if(req){

var invReq= JSON.parse(req);

// Extract Mandatory Variables
var CustomerNumber = invReq.CustomerNumber;
var AccountDescription = invReq.AccountDescription;
var AccountNumber = invReq.AccountNumber;
var AccountRoutingNumber = invReq.AccountRoutingNumber;
var AccountEmail = invReq.AccountEmail;
var CustomerName = invReq.CustomerName;

// Condition to check if mandatory values are not null and empty
if(typeof CustomerNumber ==='undefined' || CustomerNumber ==="" || CustomerNumber === null){
 context.setVariable("errorMessage","Missing CustomerNumber : "+CustomerNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof AccountDescription ==='undefined' || AccountDescription ==="" || AccountDescription === null){
 context.setVariable("errorMessage","Missing AccountDescription : "+AccountDescription);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof AccountNumber ==='undefined' || AccountNumber ==="" || AccountNumber === null){
 context.setVariable("errorMessage","Missing AccountNumber : "+AccountNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof AccountRoutingNumber ==='undefined' || AccountRoutingNumber ==="" || AccountRoutingNumber === null){
 context.setVariable("errorMessage","Missing AccountRoutingNumber : "+AccountRoutingNumber);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof AccountEmail ==='undefined' || AccountEmail ==="" || AccountEmail === null){
 context.setVariable("errorMessage","Missing AccountEmail : "+AccountEmail);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

else if(typeof CustomerName ==='undefined' || CustomerName ==="" || CustomerName === null){
 context.setVariable("errorMessage","Missing CustomerName : "+CustomerName);
 context.setVariable("validation_failed","true");
 context.setVariable("is.error",true);
 throw null;
}

}



